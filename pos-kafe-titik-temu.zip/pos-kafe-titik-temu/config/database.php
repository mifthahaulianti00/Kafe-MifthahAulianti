<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Jakarta');

define('APP_NAME', "Kafe Titik Temu Kopi POS");
define('CAFE_ADDRESS', 'Balai Baru No. 23 Kuranji, Padang, Sumatera Barat');
define('CAFE_PHONE', '(0751) 490-460 | IG: @titiktemukopi.id');
define('TAX_RATE', 0.10); // Pajak PB1 / Restoran 10%

define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'db_pos_kafe');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

try {
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=%s',
        DB_HOST,
        DB_NAME,
        DB_CHARSET
    );
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    die('
        <div style="font-family:system-ui,sans-serif;max-width:600px;margin:60px auto;padding:24px;border:1px solid #f5c2c7;background:#f8d7da;color:#842029;border-radius:12px;">
            <h3 style="margin-top:0;">Koneksi Database MySQL Gagal</h3>
            <p>Pastikan service <strong>MySQL</strong> sudah berjalan dan file <code>database.sql</code> sudah diimpor ke database <code>' . htmlspecialchars(DB_NAME) . '</code>.</p>
            <small>Detail teknis: ' . htmlspecialchars($e->getMessage()) . '</small>
        </div>
    ');
}

/**
 * Menghasilkan URL dasar aplikasi secara dinamis agar bekerja di subfolder maupun virtual host.
 */
function base_url(string $path = ''): string
{
    $scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $appRoot = preg_replace('#/(auth|dashboard|pos|products|categories|users|reports)(/.*)?$#', '', dirname($scriptName));
    if ($appRoot === '/' || $appRoot === '\\' || $appRoot === '.') {
        $appRoot = '';
    }
    return rtrim($appRoot, '/') . '/' . ltrim($path, '/');
}

/**
 * Sanitasi output HTML (XSS protection).
 */
function e(mixed $value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Format angka ke mata uang Rupiah.
 */
function rupiah(float|int|string $amount): string
{
    return 'Rp ' . number_format((float)$amount, 0, ',', '.');
}

/**
 * Menyimpan notifikasi flash sementara ke dalam session.
 */
function set_flash(string $type, string $message): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION['flash'] = [
        'type'    => $type,
        'message' => $message,
    ];
}

/**
 * Mengambil dan menghapus notifikasi flash dari session.
 */
function get_flash(): ?array
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Menghasilkan nomor faktur preview berikutnya: INV-POS-YYYYMMDD-XXXX
 */
function generate_next_invoice(PDO $pdo): string
{
    $todayPrefix = 'INV-POS-' . date('Ymd') . '-';
    $stmt = $pdo->prepare("SELECT invoice_number FROM orders WHERE invoice_number LIKE :prefix ORDER BY id DESC LIMIT 1");
    $stmt->execute([':prefix' => $todayPrefix . '%']);
    $lastInvoice = $stmt->fetchColumn();

    $nextSeq = 1;
    if ($lastInvoice) {
        $parts = explode('-', $lastInvoice);
        $lastNum = (int)end($parts);
        $nextSeq = $lastNum + 1;
    }

    return $todayPrefix . str_pad((string)$nextSeq, 4, '0', STR_PAD_LEFT);
}
