<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth_guard.php';
$user = require_admin();
$pageTitle = 'Kelola Akun Pengguna';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string)($_POST['action'] ?? '');

    try {
        if ($action === 'create') {
            $username = strtolower(trim((string)($_POST['username'] ?? '')));
            $nama     = trim((string)($_POST['nama_lengkap'] ?? ''));
            $role     = (string)($_POST['role'] ?? 'kasir');
            $password = (string)($_POST['password'] ?? '');

            if ($username === '' || $nama === '' || strlen($password) < 6) {
                throw new RuntimeException('Username, nama lengkap, dan password (minimal 6 karakter) wajib diisi.');
            }

            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("
                INSERT INTO users (username, password_hash, nama_lengkap, role, status)
                VALUES (:u, :p, :n, :r, 'aktif')
            ");
            $stmt->execute([
                ':u' => $username,
                ':p' => $hash,
                ':n' => $nama,
                ':r' => $role === 'admin' ? 'admin' : 'kasir',
            ]);
            set_flash('success', 'Akun pengguna "' . $username . '" berhasil dibuat dengan password terenkripsi Bcrypt.');
        } elseif ($action === 'toggle_status') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id === (int)$user['id']) {
                throw new RuntimeException('Anda tidak dapat menonaktifkan akun Anda sendiri.');
            }
            $stmt = $pdo->prepare("UPDATE users SET status = IF(status = 'aktif', 'nonaktif', 'aktif') WHERE id = :id");
            $stmt->execute([':id' => $id]);
            set_flash('success', 'Status akun pengguna berhasil diperbarui.');
        }
    } catch (Throwable $e) {
        set_flash('danger', $e->getMessage());
    }

    header('Location: ' . base_url('users/index.php'));
    exit;
}

$usersList = $pdo->query("SELECT id, username, nama_lengkap, role, status, created_at FROM users ORDER BY id ASC")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-white border-0 pt-4 px-4">
                <h6 class="fw-extrabold mb-0 text-dark">Tambah Pengguna Baru</h6>
            </div>
            <div class="card-body px-4 pb-4">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="create">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Nama Lengkap *</label>
                        <input type="text" name="nama_lengkap" class="form-control" placeholder="Contoh: Ayu Lestari" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Username Login *</label>
                        <input type="text" name="username" class="form-control" placeholder="kasir3" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Role Hak Akses *</label>
                        <select name="role" class="form-select">
                            <option value="kasir">Kasir / Waiter</option>
                            <option value="admin">Administrator / Manager</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Password (min. 6 karakter) *</label>
                        <input type="password" name="password" class="form-control" minlength="6" required>
                    </div>
                    <button type="submit" class="btn btn-espresso w-100 fw-bold rounded-pill">Buat Akun Pengguna</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-white border-0 pt-4 px-4">
                <h6 class="fw-extrabold mb-0 text-dark">Daftar Akun Pengguna Sistem</h6>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small text-uppercase">
                        <tr>
                            <th class="ps-4">Nama Lengkap</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th class="text-center">Status</th>
                            <th class="text-end pe-4">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usersList as $u): ?>
                            <tr>
                                <td class="ps-4 fw-bold text-dark"><?= e($u['nama_lengkap']) ?></td>
                                <td class="font-monospace small text-espresso"><?= e($u['username']) ?></td>
                                <td>
                                    <span class="badge <?= $u['role'] === 'admin' ? 'badge-pastel-peach' : 'badge-pastel-sky' ?> rounded-pill px-3">
                                        <?= $u['role'] === 'admin' ? 'Administrator / Manager' : 'Kasir / Waiter' ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <span class="badge <?= $u['status'] === 'aktif' ? 'badge-pastel-mint' : 'badge-pastel-rose' ?> rounded-pill px-3">
                                        <?= ucfirst(e($u['status'])) ?>
                                    </span>
                                </td>
                                <td class="text-end pe-4">
                                    <?php if ((int)$u['id'] !== (int)$user['id']): ?>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                            <input type="hidden" name="action" value="toggle_status">
                                            <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-espresso rounded-pill px-3">
                                                <?= $u['status'] === 'aktif' ? 'Nonaktifkan' : 'Aktifkan' ?>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="badge badge-pastel-lavender rounded-pill">Akun Aktif</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
