<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth_guard.php';
$user = require_login();
$pageTitle = 'Dashboard Eksekutif';

// 1. KPI: Total Omset Hari Ini (status = Selesai)
$stmtOmset = $pdo->query("
    SELECT COALESCE(SUM(grand_total), 0) AS total_omset, COUNT(*) AS jumlah_pesanan
    FROM orders
    WHERE DATE(created_at) = CURDATE() AND status = 'Selesai'
");
$todayStats = $stmtOmset->fetch();
$totalOmsetHariIni = (float)$todayStats['total_omset'];
$jumlahPesananHariIni = (int)$todayStats['jumlah_pesanan'];

// Pesanan diproses hari ini (info tambahan)
$stmtDiproses = $pdo->query("SELECT COUNT(*) FROM orders WHERE DATE(created_at) = CURDATE() AND status = 'Diproses'");
$jumlahDiproses = (int)$stmtDiproses->fetchColumn();

// 2. KPI: Menu Terlaris (kuantiti penjualan tertinggi pada transaksi Selesai)
$stmtTopMenu = $pdo->query("
    SELECT p.nama_produk, p.unit, COALESCE(SUM(od.kuantiti), 0) AS total_terjual
    FROM order_details od
    INNER JOIN orders o ON o.id = od.order_id
    INNER JOIN products p ON p.id = od.product_id
    WHERE o.status = 'Selesai'
    GROUP BY p.id, p.nama_produk, p.unit
    ORDER BY total_terjual DESC
    LIMIT 1
");
$topMenu = $stmtTopMenu->fetch();

// 3. KPI: Peringatan Stok Rendah (stok <= stok_minimum)
$stmtLowStock = $pdo->query("
    SELECT p.id, p.kode_produk, p.nama_produk, p.stok, p.stok_minimum, p.unit, c.nama_kategori
    FROM products p
    INNER JOIN categories c ON c.id = p.category_id
    WHERE p.stok <= p.stok_minimum
    ORDER BY p.stok ASC
");
$lowStockItems = $stmtLowStock->fetchAll();
$jumlahStokRendah = count($lowStockItems);

// 4. Grafik Omset 7 Hari Terakhir
$trendLabels = [];
$trendValues = [];
$stmtTrend = $pdo->prepare("
    SELECT COALESCE(SUM(grand_total), 0)
    FROM orders
    WHERE DATE(created_at) = :tgl AND status = 'Selesai'
");
for ($i = 6; $i >= 0; $i--) {
    $dateStr = date('Y-m-d', strtotime("-{$i} days"));
    $stmtTrend->execute([':tgl' => $dateStr]);
    $trendLabels[] = date('d M', strtotime($dateStr));
    $trendValues[] = (float)$stmtTrend->fetchColumn();
}

// 5. Grafik Distribusi Penjualan per Kategori
$stmtCatDist = $pdo->query("
    SELECT c.nama_kategori, COALESCE(SUM(od.kuantiti), 0) AS qty_terjual
    FROM categories c
    LEFT JOIN products p ON p.category_id = c.id
    LEFT JOIN order_details od ON od.product_id = p.id
    LEFT JOIN orders o ON o.id = od.order_id AND o.status = 'Selesai'
    GROUP BY c.id, c.nama_kategori
    ORDER BY qty_terjual DESC
");
$catDistRows = $stmtCatDist->fetchAll();
$catLabels = array_column($catDistRows, 'nama_kategori');
$catValues = array_map('intval', array_column($catDistRows, 'qty_terjual'));

// 6. Tabel Riwayat Cepat (8 Transaksi Terbaru)
$stmtRecent = $pdo->query("
    SELECT o.*, u.nama_lengkap AS kasir_nama
    FROM orders o
    INNER JOIN users u ON u.id = o.user_id
    ORDER BY o.created_at DESC, o.id DESC
    LIMIT 8
");
$recentOrders = $stmtRecent->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<!-- Banner Quick Action Soft Pastel -->
<div class="card border-0 shadow-sm mb-4 bg-espresso-gradient rounded-4">
    <div class="card-body p-4 d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 position-relative" style="z-index: 1;">
        <div>
            <span class="badge bg-white text-espresso shadow-sm rounded-pill px-3 py-1 fw-bold mb-2">
                <i class="bi bi-stars text-pastel-rose me-1"></i> RINGKASAN OPERASIONAL REAL-TIME
            </span>
            <h4 class="fw-extrabold mb-1 text-dark">Halo, <?= e($user['nama_lengkap']) ?>!</h4>
            <p class="mb-0 text-muted small">
                Pantau performa penjualan Kafe 'Titik Temu Kopi' hari ini atau mulai catat pesanan pelanggan secara cepat.
            </p>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="<?= e(base_url('pos/index.php')) ?>" class="btn btn-espresso fw-bold px-4 py-2 rounded-pill">
                <i class="bi bi-plus-circle-fill me-1"></i> Buat Pesanan Baru 
            </a>
            <?php if ($user['role'] === 'admin'): ?>
                <a href="<?= e(base_url('reports/index.php')) ?>" class="btn btn-outline-espresso fw-semibold px-3 py-2 rounded-pill">
                    <i class="bi bi-file-earmark-bar-graph me-1"></i> Laporan Penjualan
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- 4 KPI Utama Soft Pastel -->
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3">
        <div class="card border-0 shadow-sm h-100 rounded-4 kpi-card">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div class="kpi-icon" style="background-color: #DCFCE7; color: #166534;">
                        <i class="bi bi-cash-stack fs-4"></i>
                    </div>
                    <span class="badge badge-pastel-mint rounded-pill">Hari Ini</span>
                </div>
                <div class="text-muted small fw-bold mb-1">TOTAL OMSET HARI INI</div>
                <h4 class="fw-extrabold mb-1 text-dark"><?= e(rupiah($totalOmsetHariIni)) ?></h4>
                <small class="text-muted">Akumulasi transaksi lunas</small>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="card border-0 shadow-sm h-100 rounded-4 kpi-card">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div class="kpi-icon" style="background-color: #E0F2FE; color: #075985;">
                        <i class="bi bi-bag-check-fill fs-4"></i>
                    </div>
                    <?php if ($jumlahDiproses > 0): ?>
                        <span class="badge badge-pastel-peach rounded-pill"><?= $jumlahDiproses ?> Diproses</span>
                    <?php else: ?>
                        <span class="badge badge-pastel-sky rounded-pill">Lunas</span>
                    <?php endif; ?>
                </div>
                <div class="text-muted small fw-bold mb-1">JUMLAH PESANAN</div>
                <h4 class="fw-extrabold mb-1 text-dark"><?= $jumlahPesananHariIni ?> Transaksi</h4>
                <small class="text-muted">Status selesai hari ini</small>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="card border-0 shadow-sm h-100 rounded-4 kpi-card">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div class="kpi-icon" style="background-color: #FFEDD5; color: #9A3412;">
                        <i class="bi bi-trophy-fill fs-4"></i>
                    </div>
                    <span class="badge badge-pastel-peach rounded-pill">Best Seller</span>
                </div>
                <div class="text-muted small fw-bold mb-1">MENU TERLARIS</div>
                <h5 class="fw-extrabold mb-1 text-dark text-truncate" title="<?= e($topMenu['nama_produk'] ?? '-') ?>">
                    <?= e($topMenu['nama_produk'] ?? 'Belum ada data') ?>
                </h5>
                <small class="text-muted">
                    Terjual <strong><?= (int)($topMenu['total_terjual'] ?? 0) ?></strong> <?= e($topMenu['unit'] ?? 'item') ?>
                </small>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-xl-3">
        <div class="card border-0 shadow-sm h-100 rounded-4 kpi-card <?= $jumlahStokRendah > 0 ? 'border-start border-4' : '' ?>" style="<?= $jumlahStokRendah > 0 ? 'border-left-color: #F43F5E !important;' : '' ?>">
            <div class="card-body p-4">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div class="kpi-icon" style="background-color: #FFE4E6; color: #9F1239;">
                        <i class="bi bi-exclamation-triangle-fill fs-4"></i>
                    </div>
                    <?php if ($jumlahStokRendah > 0): ?>
                        <button type="button" class="btn btn-sm btn-pastel-rose rounded-pill py-0 px-2" data-bs-toggle="modal" data-bs-target="#lowStockModal">
                            Lihat Detail
                        </button>
                    <?php else: ?>
                        <span class="badge badge-pastel-mint rounded-pill">Aman</span>
                    <?php endif; ?>
                </div>
                <div class="text-muted small fw-bold mb-1">PERINGATAN STOK RENDAH</div>
                <h4 class="fw-extrabold mb-1 <?= $jumlahStokRendah > 0 ? 'text-pastel-rose' : 'text-dark' ?>">
                    <?= $jumlahStokRendah ?> Item Menu
                </h4>
                <small class="text-muted">Stok &le; batas minimum</small>
            </div>
        </div>
    </div>
</div>

<!-- Grafik Visual Pendukung Soft Pastel -->
<div class="row g-4 mb-4">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-header bg-white border-0 pt-4 px-4 pb-0 d-flex justify-content-between align-items-center">
                <div>
                    <h6 class="fw-bold mb-0 text-dark">Omset Penjualan (7 Hari Terakhir)</h6>
                    <small class="text-muted">Akumulasi omset harian berstatus Selesai</small>
                </div>
                <span class="badge badge-pastel-lavender rounded-pill px-3">IDR (Rp)</span>
            </div>
            <div class="card-body p-4">
                <div style="height: 270px;">
                    <canvas id="revenueTrendChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-header bg-white border-0 pt-4 px-4 pb-0">
                <h6 class="fw-bold mb-0 text-dark">Distribusi Kategori Menu</h6>
                <small class="text-muted">Total kuantiti item terjual per kategori</small>
            </div>
            <div class="card-body p-4 d-flex flex-column justify-content-center">
                <div style="height: 230px;">
                    <canvas id="categoryChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Tabel Riwayat Cepat (8 Transaksi Terbaru) -->
<div class="card border-0 shadow-sm rounded-4">
    <div class="card-header bg-white border-0 pt-4 px-4 pb-3 d-flex justify-content-between align-items-center">
        <div>
            <h6 class="fw-bold mb-0 text-dark">Riwayat Transaksi Terbaru</h6>
            <small class="text-muted">Daftar 8 pesanan terakhir yang masuk ke sistem</small>
        </div>
        <a href="<?= e(base_url('pos/history.php')) ?>" class="btn btn-sm btn-outline-espresso rounded-pill px-3">
            Lihat Semua <i class="bi bi-arrow-right ms-1"></i>
        </a>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light small text-uppercase">
                <tr>
                    <th class="ps-4">No. Faktur</th>
                    <th>Waktu</th>
                    <th>Pemesan / Meja</th>
                    <th>Kasir</th>
                    <th>Metode</th>
                    <th class="text-end">Grand Total</th>
                    <th class="text-center">Status</th>
                    <th class="text-end pe-4">Struk</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recentOrders)): ?>
                    <tr>
                        <td colspan="8" class="text-center py-4 text-muted">Belum ada transaksi tercatat.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($recentOrders as $ord): ?>
                        <?php
                        $badgeClass = match ($ord['status']) {
                            'Selesai'    => 'badge-pastel-mint',
                            'Diproses'   => 'badge-pastel-peach',
                            'Dibatalkan' => 'badge-pastel-rose',
                            default      => 'badge-pastel-lavender',
                        };
                        ?>
                        <tr>
                            <td class="ps-4 fw-bold text-espresso"><?= e($ord['invoice_number']) ?></td>
                            <td class="small text-muted"><?= date('d/m/Y H:i', strtotime($ord['created_at'])) ?></td>
                            <td>
                                <div class="fw-semibold text-dark"><?= e($ord['nama_pemesan']) ?></div>
                                <small class="text-muted">
                                    <?= e($ord['tipe_pesanan']) ?>
                                    <?= $ord['nomor_meja'] ? ' &bull; ' . e($ord['nomor_meja']) : '' ?>
                                </small>
                            </td>
                            <td class="small"><?= e($ord['kasir_nama']) ?></td>
                            <td><span class="badge badge-pastel-sky rounded-pill"><?= e($ord['metode_bayar']) ?></span></td>
                            <td class="text-end fw-bold text-dark"><?= e(rupiah($ord['grand_total'])) ?></td>
                            <td class="text-center">
                                <span class="badge <?= $badgeClass ?> rounded-pill px-3 py-1"><?= e($ord['status']) ?></span>
                            </td>
                            <td class="text-end pe-4">
                                <a href="<?= e(base_url('pos/receipt.php?id=' . (int)$ord['id'])) ?>" class="btn btn-sm btn-outline-espresso rounded-3" title="Cetak Struk">
                                    <i class="bi bi-printer"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Peringatan Stok Rendah -->
<div class="modal fade" id="lowStockModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <div class="modal-header">
                <h6 class="modal-title fw-bold text-pastel-rose"><i class="bi bi-exclamation-triangle-fill me-2"></i>Daftar Menu Stok Rendah</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-0">
                <table class="table table-sm mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3">Kode</th>
                            <th>Nama Menu</th>
                            <th class="text-center">Sisa Stok</th>
                            <th class="text-center pe-3">Min. Stok</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lowStockItems as $item): ?>
                            <tr>
                                <td class="ps-3 small fw-semibold"><?= e($item['kode_produk']) ?></td>
                                <td>
                                    <div class="fw-semibold"><?= e($item['nama_produk']) ?></div>
                                    <small class="text-muted"><?= e($item['nama_kategori']) ?></small>
                                </td>
                                <td class="text-center"><span class="badge badge-pastel-rose rounded-pill"><?= (int)$item['stok'] ?> <?= e($item['unit']) ?></span></td>
                                <td class="text-center pe-3 text-muted"><?= (int)$item['stok_minimum'] ?> <?= e($item['unit']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <?php if ($user['role'] === 'admin'): ?>
                    <a href="<?= e(base_url('products/index.php?filter=low_stock')) ?>" class="btn btn-espresso btn-sm rounded-pill px-3">
                        Kelola & Restock Menu
                    </a>
                <?php endif; ?>
                <button type="button" class="btn btn-outline-espresso btn-sm rounded-pill px-3" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<?php
$trendLabelsJson = json_encode($trendLabels, JSON_UNESCAPED_UNICODE);
$trendValuesJson = json_encode($trendValues);
$catLabelsJson   = json_encode($catLabels, JSON_UNESCAPED_UNICODE);
$catValuesJson   = json_encode($catValues);

$extraScripts = <<<HTML
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script>
const trendCtx = document.getElementById('revenueTrendChart');
if (trendCtx) {
    new Chart(trendCtx, {
        type: 'bar',
        data: {
            labels: {$trendLabelsJson},
            datasets: [{
                label: 'Omset (Rp)',
                data: {$trendValuesJson},
                backgroundColor: [
                    'rgba(249, 168, 212, 0.78)',
                    'rgba(196, 181, 253, 0.78)',
                    'rgba(147, 197, 253, 0.78)',
                    'rgba(110, 231, 183, 0.78)',
                    'rgba(253, 211, 77, 0.78)',
                    'rgba(249, 168, 212, 0.85)',
                    'rgba(167, 139, 250, 0.85)'
                ],
                borderColor: '#C4B5FD',
                borderWidth: 1,
                borderRadius: 10,
                maxBarThickness: 42
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: (ctx) => 'Rp ' + Number(ctx.raw).toLocaleString('id-ID')
                    }
                }
            },
            scales: {
                x: {
                    grid: { display: false }
                },
                y: {
                    beginAtZero: true,
                    grid: { color: '#F3EDF7' },
                    ticks: {
                        callback: (val) => 'Rp ' + Number(val).toLocaleString('id-ID')
                    }
                }
            }
        }
    });
}

const catCtx = document.getElementById('categoryChart');
if (catCtx) {
    new Chart(catCtx, {
        type: 'doughnut',
        data: {
            labels: {$catLabelsJson},
            datasets: [{
                data: {$catValuesJson},
                backgroundColor: ['#F9A8D4', '#C4B5FD', '#6EE7B7', '#FCD34D', '#93C5FD'],
                borderWidth: 3,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '64%',
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
}
</script>
HTML;
require_once __DIR__ . '/../includes/footer.php';
?>
