<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth_guard.php';
$user = require_admin();
$pageTitle = 'Kategori Menu';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string)($_POST['action'] ?? '');

    try {
        if ($action === 'create') {
            $nama = trim((string)($_POST['nama_kategori'] ?? ''));
            $status = (string)($_POST['status'] ?? 'aktif');
            if ($nama === '') {
                throw new RuntimeException('Nama kategori wajib diisi.');
            }
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $nama), '-'));
            $stmt = $pdo->prepare("INSERT INTO categories (nama_kategori, slug, status) VALUES (:nama, :slug, :status)");
            $stmt->execute([':nama' => $nama, ':slug' => $slug, ':status' => $status === 'nonaktif' ? 'nonaktif' : 'aktif']);
            set_flash('success', 'Kategori "' . $nama . '" berhasil ditambahkan.');
        } elseif ($action === 'update') {
            $id = (int)($_POST['id'] ?? 0);
            $nama = trim((string)($_POST['nama_kategori'] ?? ''));
            $status = (string)($_POST['status'] ?? 'aktif');
            if ($id <= 0 || $nama === '') {
                throw new RuntimeException('Data kategori tidak valid.');
            }
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $nama), '-'));
            $stmt = $pdo->prepare("UPDATE categories SET nama_kategori = :nama, slug = :slug, status = :status WHERE id = :id");
            $stmt->execute([':nama' => $nama, ':slug' => $slug, ':status' => $status === 'nonaktif' ? 'nonaktif' : 'aktif', ':id' => $id]);
            set_flash('success', 'Kategori berhasil diperbarui.');
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM products WHERE category_id = :id");
            $stmtCheck->execute([':id' => $id]);
            if ((int)$stmtCheck->fetchColumn() > 0) {
                throw new RuntimeException('Kategori tidak dapat dihapus karena masih memiliki produk.');
            }
            $stmtDel = $pdo->prepare("DELETE FROM categories WHERE id = :id");
            $stmtDel->execute([':id' => $id]);
            set_flash('success', 'Kategori berhasil dihapus.');
        }
    } catch (Throwable $e) {
        set_flash('danger', $e->getMessage());
    }

    header('Location: ' . base_url('categories/index.php'));
    exit;
}

$categories = $pdo->query("
    SELECT c.*, COUNT(p.id) AS total_produk
    FROM categories c
    LEFT JOIN products p ON p.category_id = c.id
    GROUP BY c.id
    ORDER BY c.id ASC
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-white border-0 pt-4 px-4">
                <h6 class="fw-extrabold mb-0 text-dark">Tambah Kategori Baru</h6>
            </div>
            <div class="card-body px-4 pb-4">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="create">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Nama Kategori *</label>
                        <input type="text" name="nama_kategori" class="form-control" placeholder="Contoh: Signature Mocktail" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Status</label>
                        <select name="status" class="form-select">
                            <option value="aktif">Aktif</option>
                            <option value="nonaktif">Nonaktif</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-espresso w-100 fw-bold rounded-pill">Simpan Kategori</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-white border-0 pt-4 px-4">
                <h6 class="fw-extrabold mb-0 text-dark">Daftar Kategori Menu</h6>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small text-uppercase">
                        <tr>
                            <th class="ps-4">Nama Kategori</th>
                            <th>Slug</th>
                            <th class="text-center">Jumlah Menu</th>
                            <th class="text-center">Status</th>
                            <th class="text-end pe-4">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $cat): ?>
                            <tr>
                                <td class="ps-4 fw-bold text-dark"><?= e($cat['nama_kategori']) ?></td>
                                <td class="small text-muted font-monospace"><?= e($cat['slug']) ?></td>
                                <td class="text-center"><span class="badge badge-pastel-lavender rounded-pill"><?= (int)$cat['total_produk'] ?> menu</span></td>
                                <td class="text-center">
                                    <span class="badge <?= $cat['status'] === 'aktif' ? 'badge-pastel-mint' : 'badge-pastel-rose' ?> rounded-pill px-3">
                                        <?= ucfirst(e($cat['status'])) ?>
                                    </span>
                                </td>
                                <td class="text-end pe-4">
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Hapus kategori ini?');">
                                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= (int)$cat['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-pastel-rose rounded-3"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
