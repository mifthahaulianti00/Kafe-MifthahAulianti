<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth_guard.php';
$user = require_admin();
$pageTitle = 'Manajemen Menu & Stok Produk';

// Handle Create / Update / Restock / Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = (string)($_POST['action'] ?? '');

    try {
        if ($action === 'create') {
            $kode   = strtoupper(trim((string)($_POST['kode_produk'] ?? '')));
            $nama   = trim((string)($_POST['nama_produk'] ?? ''));
            $catId  = (int)($_POST['category_id'] ?? 0);
            $jual   = max(0, (float)($_POST['harga_jual'] ?? 0));
            $pokok  = max(0, (float)($_POST['harga_pokok'] ?? 0));
            $stok   = max(0, (int)($_POST['stok'] ?? 0));
            $minSt  = max(0, (int)($_POST['stok_minimum'] ?? 10));
            $unit   = trim((string)($_POST['unit'] ?? 'Cup'));

            if ($kode === '' || $nama === '' || $catId <= 0 || $jual <= 0) {
                throw new RuntimeException('Kode, nama menu, kategori, dan harga jual wajib diisi dengan benar.');
            }

            $stmt = $pdo->prepare("
                INSERT INTO products (category_id, kode_produk, nama_produk, harga_jual, harga_pokok, stok, stok_minimum, unit)
                VALUES (:cat, :kode, :nama, :jual, :pokok, :stok, :minst, :unit)
            ");
            $stmt->execute([
                ':cat'   => $catId,
                ':kode'  => $kode,
                ':nama'  => $nama,
                ':jual'  => $jual,
                ':pokok' => $pokok,
                ':stok'  => $stok,
                ':minst' => $minSt,
                ':unit'  => $unit !== '' ? $unit : 'Cup',
            ]);
            set_flash('success', 'Menu "' . $nama . '" berhasil ditambahkan.');
        } elseif ($action === 'update') {
            $id     = (int)($_POST['id'] ?? 0);
            $kode   = strtoupper(trim((string)($_POST['kode_produk'] ?? '')));
            $nama   = trim((string)($_POST['nama_produk'] ?? ''));
            $catId  = (int)($_POST['category_id'] ?? 0);
            $jual   = max(0, (float)($_POST['harga_jual'] ?? 0));
            $pokok  = max(0, (float)($_POST['harga_pokok'] ?? 0));
            $stok   = max(0, (int)($_POST['stok'] ?? 0));
            $minSt  = max(0, (int)($_POST['stok_minimum'] ?? 10));
            $unit   = trim((string)($_POST['unit'] ?? 'Cup'));

            if ($id <= 0 || $kode === '' || $nama === '' || $catId <= 0 || $jual <= 0) {
                throw new RuntimeException('Data pembaruan menu tidak lengkap.');
            }

            $stmt = $pdo->prepare("
                UPDATE products
                SET category_id = :cat, kode_produk = :kode, nama_produk = :nama,
                    harga_jual = :jual, harga_pokok = :pokok, stok = :stok, stok_minimum = :minst, unit = :unit
                WHERE id = :id
            ");
            $stmt->execute([
                ':cat'   => $catId,
                ':kode'  => $kode,
                ':nama'  => $nama,
                ':jual'  => $jual,
                ':pokok' => $pokok,
                ':stok'  => $stok,
                ':minst' => $minSt,
                ':unit'  => $unit !== '' ? $unit : 'Cup',
                ':id'    => $id,
            ]);
            set_flash('success', 'Data menu "' . $nama . '" berhasil diperbarui.');
        } elseif ($action === 'restock') {
            $id  = (int)($_POST['id'] ?? 0);
            $add = (int)($_POST['tambah_stok'] ?? 0);
            if ($id <= 0 || $add <= 0) {
                throw new RuntimeException('Jumlah penambahan stok harus lebih dari 0.');
            }
            $stmt = $pdo->prepare("UPDATE products SET stok = stok + :add WHERE id = :id");
            $stmt->execute([':add' => $add, ':id' => $id]);
            set_flash('success', 'Stok berhasil ditambahkan sebanyak +' . $add . '.');
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $stmtCheck = $pdo->prepare("SELECT COUNT(*) FROM order_details WHERE product_id = :id");
            $stmtCheck->execute([':id' => $id]);
            if ((int)$stmtCheck->fetchColumn() > 0) {
                throw new RuntimeException('Menu tidak dapat dihapus karena sudah tercatat dalam riwayat transaksi.');
            }
            $stmtDel = $pdo->prepare("DELETE FROM products WHERE id = :id");
            $stmtDel->execute([':id' => $id]);
            set_flash('success', 'Menu berhasil dihapus.');
        }
    } catch (Throwable $e) {
        set_flash('danger', $e->getMessage());
    }

    header('Location: ' . base_url('products/index.php'));
    exit;
}

$filterCat = (int)($_GET['category_id'] ?? 0);
$filterLow = ($_GET['filter'] ?? '') === 'low_stock';
$searchQ   = trim((string)($_GET['q'] ?? ''));

$categories = $pdo->query("SELECT id, nama_kategori FROM categories ORDER BY id ASC")->fetchAll();

$where = [];
$params = [];
if ($filterCat > 0) {
    $where[] = "p.category_id = :cat";
    $params[':cat'] = $filterCat;
}
if ($filterLow) {
    $where[] = "p.stok <= p.stok_minimum";
}
if ($searchQ !== '') {
    $where[] = "(p.nama_produk LIKE :q1 OR p.kode_produk LIKE :q2)";
    $params[':q1'] = '%' . $searchQ . '%';
    $params[':q2'] = '%' . $searchQ . '%';
}

$sql = "
    SELECT p.*, c.nama_kategori
    FROM products p
    INNER JOIN categories c ON c.id = p.category_id
";
if (!empty($where)) {
    $sql .= " WHERE " . implode(' AND ', $where);
}
$sql .= " ORDER BY c.id ASC, p.kode_produk ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card border-0 shadow-sm rounded-4 mb-4">
    <div class="card-header bg-white border-0 pt-4 px-4 pb-3 d-flex flex-wrap justify-content-between align-items-center gap-2">
        <div>
            <h6 class="fw-extrabold mb-0 text-dark">Data Menu &amp; Inventori Stok</h6>
            <small class="text-muted">Kelola harga jual, HPP (harga pokok), dan batas minimum stok menu</small>
        </div>
        <button type="button" class="btn btn-espresso btn-sm fw-bold rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#addProductModal">
            <i class="bi bi-plus-circle-fill me-1"></i> Tambah Menu Baru
        </button>
    </div>

    <div class="card-body px-4 pt-0 pb-3">
        <form method="GET" class="row g-2 align-items-center bg-cream-soft p-3 rounded-4 border">
            <div class="col-md-4">
                <input type="text" name="q" class="form-control form-control-sm" value="<?= e($searchQ) ?>" placeholder="Cari kode atau nama menu...">
            </div>
            <div class="col-md-3">
                <select name="category_id" class="form-select form-select-sm">
                    <option value="0">Semua Kategori</option>
                    <?php foreach ($categories as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= $filterCat === (int)$c['id'] ? 'selected' : '' ?>>
                            <?= e($c['nama_kategori']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="filter" value="low_stock" id="chkLow" <?= $filterLow ? 'checked' : '' ?>>
                    <label class="form-check-label small fw-semibold" for="chkLow">Hanya Stok Rendah (&le; Min)</label>
                </div>
            </div>
            <div class="col-md-2 text-end">
                <button type="submit" class="btn btn-sm btn-espresso w-100 rounded-pill">Filter</button>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light small text-uppercase">
                <tr>
                    <th class="ps-4">Kode</th>
                    <th>Nama Menu</th>
                    <th>Kategori</th>
                    <th class="text-end">Harga Pokok</th>
                    <th class="text-end">Harga Jual</th>
                    <th class="text-center">Stok</th>
                    <th class="text-end pe-4">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                    <tr><td colspan="7" class="text-center py-4 text-muted">Tidak ada data menu sesuai filter.</td></tr>
                <?php else: ?>
                    <?php foreach ($products as $p): ?>
                        <?php $isLow = ((int)$p['stok'] <= (int)$p['stok_minimum']); ?>
                        <tr>
                            <td class="ps-4 fw-semibold font-monospace text-espresso"><?= e($p['kode_produk']) ?></td>
                            <td>
                                <div class="fw-bold text-dark"><?= e($p['nama_produk']) ?></div>
                                <small class="text-muted">Satuan: <?= e($p['unit']) ?></small>
                            </td>
                            <td><span class="badge badge-pastel-lavender rounded-pill"><?= e($p['nama_kategori']) ?></span></td>
                            <td class="text-end text-muted small"><?= e(rupiah($p['harga_pokok'])) ?></td>
                            <td class="text-end fw-bold text-espresso"><?= e(rupiah($p['harga_jual'])) ?></td>
                            <td class="text-center">
                                <?php if ($isLow): ?>
                                    <span class="badge badge-pastel-rose rounded-pill"><?= (int)$p['stok'] ?> <?= e($p['unit']) ?> (Rendah)</span>
                                <?php else: ?>
                                    <span class="badge badge-pastel-mint rounded-pill"><?= (int)$p['stok'] ?> <?= e($p['unit']) ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end pe-4">
                                <div class="d-inline-flex gap-1">
                                    <button type="button" class="btn btn-sm btn-pastel-mint rounded-3" title="Tambah Stok"
                                            onclick='openRestockModal(<?= (int)$p["id"] ?>, <?= json_encode($p["nama_produk"]) ?>)'>
                                        <i class="bi bi-plus-square"></i>
                                    </button>
                                    <button type="button" class="btn btn-sm btn-pastel-sky rounded-3" title="Edit Menu"
                                            onclick='openEditProductModal(<?= json_encode($p) ?>)'>
                                        <i class="bi bi-pencil"></i>
                                    </button>
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Hapus menu ini?');">
                                        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-pastel-rose rounded-3" title="Hapus">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Tambah Menu -->
<div class="modal fade" id="addProductModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" class="modal-content border-0 shadow rounded-4">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="create">
            <div class="modal-header">
                <h6 class="modal-title fw-bold text-dark">Tambah Menu Baru</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Kode Menu *</label>
                        <input type="text" name="kode_produk" class="form-control" placeholder="CF-005" required>
                    </div>
                    <div class="col-md-8">
                        <label class="form-label small fw-semibold">Kategori *</label>
                        <select name="category_id" class="form-select" required>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= (int)$c['id'] ?>"><?= e($c['nama_kategori']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-semibold">Nama Menu *</label>
                        <input type="text" name="nama_produk" class="form-control" placeholder="Contoh: Es Kopi Pandan" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Harga Pokok / HPP (Rp)</label>
                        <input type="number" name="harga_pokok" class="form-control" min="0" value="10000" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Harga Jual (Rp) *</label>
                        <input type="number" name="harga_jual" class="form-control" min="500" value="24000" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Stok Awal *</label>
                        <input type="number" name="stok" class="form-control" min="0" value="25" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Stok Minimum</label>
                        <input type="number" name="stok_minimum" class="form-control" min="0" value="10" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Satuan</label>
                        <input type="text" name="unit" class="form-control" value="Cup" required>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-espresso rounded-pill px-3" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-espresso fw-semibold rounded-pill px-4">Simpan Menu</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Edit Menu -->
<div class="modal fade" id="editProductModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" class="modal-content border-0 shadow rounded-4">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" id="edit_id">
            <div class="modal-header">
                <h6 class="modal-title fw-bold text-dark">Edit Data Menu</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Kode Menu *</label>
                        <input type="text" name="kode_produk" id="edit_kode" class="form-control" required>
                    </div>
                    <div class="col-md-8">
                        <label class="form-label small fw-semibold">Kategori *</label>
                        <select name="category_id" id="edit_cat" class="form-select" required>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= (int)$c['id'] ?>"><?= e($c['nama_kategori']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-semibold">Nama Menu *</label>
                        <input type="text" name="nama_produk" id="edit_nama" class="form-control" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Harga Pokok (Rp)</label>
                        <input type="number" name="harga_pokok" id="edit_pokok" class="form-control" min="0" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Harga Jual (Rp) *</label>
                        <input type="number" name="harga_jual" id="edit_jual" class="form-control" min="500" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Stok Saat Ini</label>
                        <input type="number" name="stok" id="edit_stok" class="form-control" min="0" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Stok Minimum</label>
                        <input type="number" name="stok_minimum" id="edit_min" class="form-control" min="0" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-semibold">Satuan</label>
                        <input type="text" name="unit" id="edit_unit" class="form-control" required>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-espresso rounded-pill px-3" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-espresso fw-semibold rounded-pill px-4">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Restock Cepat -->
<div class="modal fade" id="restockModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <form method="POST" class="modal-content border-0 shadow rounded-4">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="action" value="restock">
            <input type="hidden" name="id" id="restock_id">
            <div class="modal-header">
                <h6 class="modal-title fw-bold text-dark">Restock Menu</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="small text-muted mb-2" id="restock_name"></p>
                <label class="form-label small fw-semibold">Tambah Jumlah Stok</label>
                <input type="number" name="tambah_stok" class="form-control" min="1" value="15" required>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-pastel-mint btn-sm w-100 rounded-pill py-2">Tambah Stok Sekarang</button>
            </div>
        </form>
    </div>
</div>

<?php
$extraScripts = <<<HTML
<script>
function openEditProductModal(p) {
    document.getElementById('edit_id').value = p.id;
    document.getElementById('edit_kode').value = p.kode_produk;
    document.getElementById('edit_cat').value = p.category_id;
    document.getElementById('edit_nama').value = p.nama_produk;
    document.getElementById('edit_pokok').value = parseInt(p.harga_pokok, 10);
    document.getElementById('edit_jual').value = parseInt(p.harga_jual, 10);
    document.getElementById('edit_stok').value = p.stok;
    document.getElementById('edit_min').value = p.stok_minimum;
    document.getElementById('edit_unit').value = p.unit;
    new bootstrap.Modal(document.getElementById('editProductModal')).show();
}
function openRestockModal(id, nama) {
    document.getElementById('restock_id').value = id;
    document.getElementById('restock_name').textContent = nama;
    new bootstrap.Modal(document.getElementById('restockModal')).show();
}
</script>
HTML;
require_once __DIR__ . '/../includes/footer.php';
?>
