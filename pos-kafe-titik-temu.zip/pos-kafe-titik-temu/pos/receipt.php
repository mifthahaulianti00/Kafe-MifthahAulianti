<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth_guard.php';
$user = require_login();

$orderId = (int)($_GET['id'] ?? 0);
$paperSize = (string)($_GET['size'] ?? '80mm');
if (!in_array($paperSize, ['80mm', '58mm', 'a4'], true)) {
    $paperSize = '80mm';
}

$stmt = $pdo->prepare("
    SELECT o.*, u.nama_lengkap AS kasir_nama
    FROM orders o
    INNER JOIN users u ON u.id = o.user_id
    WHERE o.id = :id
    LIMIT 1
");
$stmt->execute([':id' => $orderId]);
$order = $stmt->fetch();

if (!$order) {
    set_flash('danger', 'Data transaksi struk tidak ditemukan.');
    header('Location: ' . base_url('pos/history.php'));
    exit;
}

$stmtDetails = $pdo->prepare("
    SELECT od.*, p.nama_produk, p.kode_produk
    FROM order_details od
    INNER JOIN products p ON p.id = od.product_id
    WHERE od.order_id = :oid
    ORDER BY od.id ASC
");
$stmtDetails->execute([':oid' => $orderId]);
$items = $stmtDetails->fetchAll();

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk <?= e($order['invoice_number']) ?> — Kafe 'Titik Temu Kopi'</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #FFF5F8 0%, #F7F5FF 55%, #F2F9FF 100%);
            min-height: 100vh;
            font-family: 'Courier New', Courier, monospace;
        }
        .toolbar-print {
            font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
        }
        .btn-pastel-main {
            background: linear-gradient(135deg, #E57BA5 0%, #9A86E2 100%);
            color: #fff;
            border: none;
            box-shadow: 0 6px 16px rgba(154, 134, 226, 0.28);
        }
        .btn-pastel-main:hover {
            color: #fff;
            opacity: 0.94;
        }
        .receipt-sheet {
            background: #ffffff;
            margin: 24px auto;
            padding: 22px 18px;
            box-shadow: 0 18px 40px rgba(139, 122, 216, 0.14);
            color: #111827;
            border-top: 6px solid #C4B5FD;
            border-radius: 10px;
            position: relative;
        }
        .receipt-80mm { width: 80mm; font-size: 12px; }
        .receipt-58mm { width: 58mm; font-size: 10.5px; padding: 14px 10px; }
        .receipt-a4   { width: 210mm; max-width: 95%; font-family: 'Plus Jakarta Sans', system-ui, sans-serif; font-size: 14px; padding: 38px; border-radius: 16px; }
        .dashed-line  { border-top: 1px dashed #9CA3AF; margin: 9px 0; }
        @media print {
            body { background: #ffffff !important; margin: 0; }
            .no-print { display: none !important; }
            .receipt-sheet {
                box-shadow: none !important;
                border-top: none !important;
                border-radius: 0 !important;
                margin: 0 !important;
                width: 100% !important;
            }
        }
    </style>
</head>
<body>

<div class="container py-3 no-print toolbar-print">
    <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show rounded-4 shadow-sm border-0">
            <i class="bi bi-check-circle-fill me-2"></i><?= e($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm rounded-4" style="border: 1px solid #EDE4F0 !important;">
        <div class="card-body d-flex flex-wrap justify-content-between align-items-center gap-2">
            <div class="d-flex flex-wrap gap-2">
                <a href="<?= e(base_url('pos/index.php')) ?>" class="btn btn-light border btn-sm rounded-pill px-3">
                    <i class="bi bi-arrow-left me-1"></i> Transaksi Baru
                </a>
                <a href="<?= e(base_url('pos/history.php')) ?>" class="btn btn-light border btn-sm rounded-pill px-3">
                    <i class="bi bi-receipt me-1"></i> Riwayat Transaksi
                </a>
            </div>

            <div class="d-flex flex-wrap align-items-center gap-2">
                <span class="small text-muted fw-semibold">Format Kertas:</span>
                <div class="btn-group btn-group-sm">
                    <a href="?id=<?= $orderId ?>&size=80mm" class="btn <?= $paperSize === '80mm' ? 'btn-pastel-main fw-bold' : 'btn-outline-secondary' ?>">Thermal 80mm</a>
                    <a href="?id=<?= $orderId ?>&size=58mm" class="btn <?= $paperSize === '58mm' ? 'btn-pastel-main fw-bold' : 'btn-outline-secondary' ?>">Thermal 58mm</a>
                    <a href="?id=<?= $orderId ?>&size=a4" class="btn <?= $paperSize === 'a4' ? 'btn-pastel-main fw-bold' : 'btn-outline-secondary' ?>">Invoice A4</a>
                </div>
                <button type="button" class="btn btn-pastel-main btn-sm fw-bold ms-2 px-4 rounded-pill" onclick="window.print()">
                    <i class="bi bi-printer-fill me-1"></i> Cetak Sekarang
                </button>
            </div>
        </div>
    </div>
</div>

<div class="receipt-sheet receipt-<?= e($paperSize) ?>">
    <div class="text-center">
        <div class="fw-bold fs-6">KAFE 'TITIK TEMU KOPI'</div>
        <div><?= e(CAFE_ADDRESS) ?></div>
        <div><?= e(CAFE_PHONE) ?></div>
    </div>

    <div class="dashed-line"></div>

    <div>
        <div class="d-flex justify-content-between">
            <span>No. Faktur:</span>
            <strong><?= e($order['invoice_number']) ?></strong>
        </div>
        <div class="d-flex justify-content-between">
            <span>Waktu:</span>
            <span><?= date('d/m/Y H:i', strtotime($order['created_at'])) ?></span>
        </div>
        <div class="d-flex justify-content-between">
            <span>Kasir:</span>
            <span><?= e($order['kasir_nama']) ?></span>
        </div>
        <div class="d-flex justify-content-between">
            <span>Pemesan:</span>
            <span><?= e($order['nama_pemesan']) ?></span>
        </div>
        <div class="d-flex justify-content-between">
            <span>Layanan:</span>
            <strong><?= e($order['tipe_pesanan']) ?><?= $order['nomor_meja'] ? ' (' . e($order['nomor_meja']) . ')' : '' ?></strong>
        </div>
    </div>

    <div class="dashed-line"></div>

    <?php foreach ($items as $item): ?>
        <div class="mb-2">
            <div class="fw-bold"><?= e($item['nama_produk']) ?></div>
            <div class="d-flex justify-content-between">
                <span><?= (int)$item['kuantiti'] ?> x <?= number_format((float)$item['harga_satuan'], 0, ',', '.') ?></span>
                <span><?= number_format((float)$item['subtotal_baris'], 0, ',', '.') ?></span>
            </div>
            <?php if (!empty($item['catatan_khusus'])): ?>
                <div class="fst-italic text-muted">* <?= e($item['catatan_khusus']) ?></div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>

    <div class="dashed-line"></div>

    <div class="d-flex justify-content-between">
        <span>Subtotal</span>
        <span><?= e(rupiah($order['total_subtotal'])) ?></span>
    </div>
    <?php if ((float)$order['diskon_nominal'] > 0): ?>
        <div class="d-flex justify-content-between">
            <span>Diskon</span>
            <span>-<?= e(rupiah($order['diskon_nominal'])) ?></span>
        </div>
    <?php endif; ?>
    <div class="d-flex justify-content-between">
        <span>Pajak PB1 (10%)</span>
        <span><?= e(rupiah($order['pajak_nominal'])) ?></span>
    </div>

    <div class="dashed-line"></div>

    <div class="d-flex justify-content-between fw-bold fs-6">
        <span>GRAND TOTAL</span>
        <span><?= e(rupiah($order['grand_total'])) ?></span>
    </div>
    <div class="d-flex justify-content-between mt-1">
        <span>Metode Bayar</span>
        <span><?= e($order['metode_bayar']) ?></span>
    </div>
    <div class="d-flex justify-content-between">
        <span>Dibayar</span>
        <span><?= e(rupiah($order['uang_dibayar'])) ?></span>
    </div>
    <div class="d-flex justify-content-between">
        <span>Kembalian</span>
        <span><?= e(rupiah($order['uang_kembali'])) ?></span>
    </div>
    <div class="d-flex justify-content-between">
        <span>Status</span>
        <strong><?= strtoupper(e($order['status'])) ?></strong>
    </div>

    <?php if (!empty($order['catatan_pesanan'])): ?>
        <div class="dashed-line"></div>
        <div>Catatan: <?= e($order['catatan_pesanan']) ?></div>
    <?php endif; ?>

    <div class="dashed-line"></div>

    <div class="text-center mt-2">
        <div>Terima kasih telah berkunjung ke</div>
        <strong>Kafe 'Titik Temu Kopi'</strong>
        <div class="mt-1">WiFi: TitikTemu_Guest / kopi2026</div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
