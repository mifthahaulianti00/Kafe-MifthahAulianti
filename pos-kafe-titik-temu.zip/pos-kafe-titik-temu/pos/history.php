<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth_guard.php';
$user = require_login();
$pageTitle = 'Riwayat Transaksi';

// Proses perubahan status pesanan (Diproses -> Selesai / Dibatalkan dengan restore stok)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['order_id'])) {
    verify_csrf();
    $orderId = (int)$_POST['order_id'];
    $newStatus = (string)$_POST['action'];

    if (in_array($newStatus, ['Selesai', 'Dibatalkan'], true)) {
        try {
            $pdo->beginTransaction();
            $stmtGet = $pdo->prepare("SELECT * FROM orders WHERE id = :id FOR UPDATE");
            $stmtGet->execute([':id' => $orderId]);
            $order = $stmtGet->fetch();

            if (!$order) {
                throw new RuntimeException('Transaksi tidak ditemukan.');
            }
            if ($user['role'] !== 'admin' && (int)$order['user_id'] !== (int)$user['id']) {
                throw new RuntimeException('Anda tidak memiliki izin mengubah transaksi kasir lain.');
            }
            if ($order['status'] === 'Dibatalkan') {
                throw new RuntimeException('Transaksi yang sudah dibatalkan tidak dapat diubah.');
            }

            // Jika dibatalkan, kembalikan stok menu
            if ($newStatus === 'Dibatalkan' && $order['status'] !== 'Dibatalkan') {
                $stmtItems = $pdo->prepare("SELECT product_id, kuantiti FROM order_details WHERE order_id = :oid");
                $stmtItems->execute([':oid' => $orderId]);
                $restoreStmt = $pdo->prepare("UPDATE products SET stok = stok + :qty WHERE id = :pid");
                foreach ($stmtItems->fetchAll() as $it) {
                    $restoreStmt->execute([
                        ':qty' => (int)$it['kuantiti'],
                        ':pid' => (int)$it['product_id'],
                    ]);
                }
            }

            $stmtUpd = $pdo->prepare("UPDATE orders SET status = :st WHERE id = :id");
            $stmtUpd->execute([':st' => $newStatus, ':id' => $orderId]);

            $pdo->commit();
            set_flash('success', 'Status faktur ' . $order['invoice_number'] . ' diperbarui menjadi ' . $newStatus . '.');
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            set_flash('danger', $e->getMessage());
        }
    }
    header('Location: ' . base_url('pos/history.php'));
    exit;
}

// Kasir hanya melihat transaksinya sendiri; Admin melihat seluruh transaksi
$sql = "
    SELECT o.*, u.nama_lengkap AS kasir_nama,
           GROUP_CONCAT(CONCAT(p.nama_produk, ' (', od.kuantiti, 'x)') SEPARATOR ', ') AS ringkasan_item
    FROM orders o
    INNER JOIN users u ON u.id = o.user_id
    LEFT JOIN order_details od ON od.order_id = o.id
    LEFT JOIN products p ON p.id = od.product_id
";
$params = [];
if ($user['role'] !== 'admin') {
    $sql .= " WHERE o.user_id = :uid ";
    $params[':uid'] = (int)$user['id'];
}
$sql .= " GROUP BY o.id ORDER BY o.created_at DESC, o.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="card border-0 shadow-sm rounded-4">
    <div class="card-header bg-white border-0 pt-4 px-4 pb-3 d-flex flex-wrap justify-content-between align-items-center gap-2">
        <div>
            <h6 class="fw-extrabold mb-0 text-dark">
                <?= $user['role'] === 'admin' ? 'Semua Riwayat Transaksi' : 'Riwayat Transaksi Saya (' . e($user['nama_lengkap']) . ')' ?>
            </h6>
            <small class="text-muted">Total <?= count($orders) ?> transaksi tercatat</small>
        </div>
        <a href="<?= e(base_url('pos/index.php')) ?>" class="btn btn-espresso btn-sm fw-bold rounded-pill px-3">
            <i class="bi bi-plus-circle me-1"></i> Pesanan Baru
        </a>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light small text-uppercase">
                <tr>
                    <th class="ps-4">No. Faktur</th>
                    <th>Tanggal &amp; Jam</th>
                    <th>Pemesan / Tipe</th>
                    <th>Item Pesanan</th>
                    <th>Kasir</th>
                    <th class="text-end">Grand Total</th>
                    <th class="text-center">Status</th>
                    <th class="text-end pe-4">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($orders)): ?>
                    <tr>
                        <td colspan="8" class="text-center py-5 text-muted">Belum ada riwayat transaksi.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($orders as $ord): ?>
                        <?php
                        $badgeClass = match ($ord['status']) {
                            'Selesai'    => 'badge-pastel-mint',
                            'Diproses'   => 'badge-pastel-peach',
                            'Dibatalkan' => 'badge-pastel-rose',
                            default      => 'badge-pastel-lavender',
                        };
                        ?>
                        <tr>
                            <td class="ps-4 fw-bold text-espresso"><?= e($ord['invoice_number']) ?></td>
                            <td class="small text-muted"><?= date('d/m/Y H:i', strtotime($ord['created_at'])) ?></td>
                            <td>
                                <div class="fw-semibold text-dark"><?= e($ord['nama_pemesan']) ?></div>
                                <small class="text-muted">
                                    <?= e($ord['tipe_pesanan']) ?>
                                    <?= $ord['nomor_meja'] ? ' (' . e($ord['nomor_meja']) . ')' : '' ?>
                                </small>
                            </td>
                            <td class="small" style="max-width: 240px;"><?= e($ord['ringkasan_item'] ?? '-') ?></td>
                            <td class="small"><?= e($ord['kasir_nama']) ?></td>
                            <td class="text-end fw-bold text-dark">
                                <?= e(rupiah($ord['grand_total'])) ?>
                                <div class="text-muted fw-normal" style="font-size: 0.72rem;"><?= e($ord['metode_bayar']) ?></div>
                            </td>
                            <td class="text-center">
                                <span class="badge <?= $badgeClass ?> rounded-pill px-3"><?= e($ord['status']) ?></span>
                            </td>
                            <td class="text-end pe-4">
                                <div class="d-inline-flex gap-1">
                                    <a href="<?= e(base_url('pos/receipt.php?id=' . (int)$ord['id'])) ?>" class="btn btn-sm btn-outline-espresso rounded-3" title="Cetak Struk">
                                        <i class="bi bi-printer"></i>
                                    </a>
                                    <?php if ($ord['status'] === 'Diproses'): ?>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                            <input type="hidden" name="order_id" value="<?= (int)$ord['id'] ?>">
                                            <button type="submit" name="action" value="Selesai" class="btn btn-sm btn-pastel-mint rounded-3" title="Tandai Selesai">
                                                <i class="bi bi-check-lg"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    <?php if ($ord['status'] !== 'Dibatalkan'): ?>
                                        <form method="POST" class="d-inline" onsubmit="return confirm('Batalkan transaksi ini dan kembalikan stok menu?');">
                                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                            <input type="hidden" name="order_id" value="<?= (int)$ord['id'] ?>">
                                            <button type="submit" name="action" value="Dibatalkan" class="btn btn-sm btn-pastel-rose rounded-3" title="Batalkan Pesanan">
                                                <i class="bi bi-x-lg"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
