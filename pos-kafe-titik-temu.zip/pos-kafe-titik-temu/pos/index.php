<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth_guard.php';
$user = require_login();
$pageTitle = 'Kasir & Pemesanan Baru';

$nextInvoice = generate_next_invoice($pdo);

// Ambil kategori aktif
$categories = $pdo->query("SELECT id, nama_kategori, slug FROM categories WHERE status = 'aktif' ORDER BY id ASC")->fetchAll();

// Ambil semua menu makanan/minuman beserta stok & slug kategori
$products = $pdo->query("
    SELECT p.id, p.category_id, p.kode_produk, p.nama_produk, p.harga_jual, p.stok, p.stok_minimum, p.unit,
           c.nama_kategori, c.slug AS category_slug
    FROM products p
    INNER JOIN categories c ON c.id = p.category_id
    WHERE c.status = 'aktif'
    ORDER BY c.id ASC, p.nama_produk ASC
")->fetchAll();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="row g-4">
    <!-- Kiri: Katalog Menu Visual Interaktif Soft Pastel -->
    <div class="col-lg-5">
        <div class="card rounded-4 h-100">
            <div class="card-header bg-white border-0 pt-4 px-4 pb-3">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h6 class="fw-extrabold mb-0 text-dark"><i class="bi bi-cup-hot-fill me-1 text-pastel-rose"></i> Katalog Menu Kafe</h6>
                        <small class="text-muted">Klik kartu menu untuk menambahkan ke keranjang</small>
                    </div>
                    <span class="badge badge-pastel-lavender rounded-pill px-3 py-1"><?= count($products) ?> Item</span>
                </div>

                <div class="input-group input-group-sm mb-3">
                    <span class="input-group-text bg-cream-soft"><i class="bi bi-search text-pastel-rose"></i></span>
                    <input type="text" id="menuSearchInput" class="form-control" placeholder="Cari menu atau kode (tekan / untuk fokus)...">
                    <button type="button" class="btn btn-outline-espresso" id="clearSearchBtn" title="Bersihkan Pencarian">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </div>

                <div class="d-flex flex-wrap gap-1" id="categoryFilterPills">
                    <button type="button" class="btn btn-sm btn-espresso active rounded-pill px-3" data-cat="all">Semua</button>
                    <?php foreach ($categories as $cat): ?>
                        <button type="button" class="btn btn-sm btn-outline-secondary rounded-pill px-3" data-cat="<?= (int)$cat['id'] ?>">
                            <?= e($cat['nama_kategori']) ?>
                        </button>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="card-body px-4 pt-1 pb-4" style="max-height: 700px; overflow-y: auto;">
                <div class="row g-2.5" id="menuCatalogGrid">
                    <?php foreach ($products as $prod): ?>
                        <?php
                        $outOfStock = ((int)$prod['stok'] <= 0);
                        $isLow = ((int)$prod['stok'] > 0 && (int)$prod['stok'] <= (int)$prod['stok_minimum']);
                        $catClass = match ($prod['category_slug']) {
                            'coffee'     => 'cat-coffee',
                            'non-coffee' => 'cat-non-coffee',
                            'food'       => 'cat-food',
                            'pastry'     => 'cat-pastry',
                            default      => 'cat-coffee',
                        };
                        $catIcon = match ($prod['category_slug']) {
                            'coffee'     => 'bi-cup-hot-fill',
                            'non-coffee' => 'bi-cup-straw',
                            'food'       => 'bi-egg-fried',
                            'pastry'     => 'bi-cake2-fill',
                            default      => 'bi-cup-fill',
                        };
                        ?>
                        <div class="col-sm-6 menu-catalog-item"
                             data-cat="<?= (int)$prod['category_id'] ?>"
                             data-search="<?= e(strtolower($prod['kode_produk'] . ' ' . $prod['nama_produk'] . ' ' . $prod['nama_kategori'])) ?>">
                            <div class="card h-100 menu-pick-card <?= $outOfStock ? 'opacity-50 bg-light' : '' ?>"
                                 <?php if (!$outOfStock): ?>
                                     onclick="quickAddProduct(<?= (int)$prod['id'] ?>)"
                                     role="button"
                                     tabindex="0"
                                 <?php endif; ?>>
                                <div class="card-body p-3 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="cat-icon-badge <?= $catClass ?>">
                                                <i class="bi <?= $catIcon ?>"></i>
                                            </span>
                                            <?php if ($outOfStock): ?>
                                                <span class="badge badge-pastel-rose rounded-pill">Stok Habis</span>
                                            <?php elseif ($isLow): ?>
                                                <span class="badge badge-pastel-peach rounded-pill">Sisa <?= (int)$prod['stok'] ?></span>
                                            <?php else: ?>
                                                <span class="badge badge-pastel-mint rounded-pill">Stok <?= (int)$prod['stok'] ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="fw-bold small text-dark mb-1 lh-sm"><?= e($prod['nama_produk']) ?></div>
                                        <div class="text-muted" style="font-size: 0.72rem;">
                                            <?= e($prod['kode_produk']) ?> &bull; <?= e($prod['nama_kategori']) ?>
                                        </div>
                                    </div>

                                    <div class="mt-3 pt-2 border-top d-flex justify-content-between align-items-center">
                                        <span class="fw-extrabold text-espresso small"><?= e(rupiah($prod['harga_jual'])) ?></span>
                                        <?php if (!$outOfStock): ?>
                                            <span class="badge badge-pastel-lavender rounded-pill px-2 py-1">
                                                <i class="bi bi-plus-lg"></i> Tambah
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Kanan: Form Transaksi Master-Detail & Checkout Soft Pastel -->
    <div class="col-lg-7">
        <form method="POST" action="<?= e(base_url('pos/store.php')) ?>" id="posOrderForm" novalidate>
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

            <div class="card rounded-4 mb-3">
                <div class="card-header bg-white border-0 pt-4 px-4 pb-2 d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <div>
                        <span class="badge badge-pastel-lavender rounded-pill px-3">FORM TRANSAKSI</span>
                        <h6 class="fw-extrabold mb-0 mt-1 text-dark">Rincian Pesanan &amp; Pembayaran</h6>
                    </div>
                    <div class="text-end bg-cream-soft px-3 py-2 rounded-4 border">
                        <small class="text-muted d-block fw-semibold" style="font-size: 0.68rem;">NOMOR FAKTUR OTOMATIS</small>
                        <span class="fw-bold text-pastel-rose font-monospace"><?= e($nextInvoice) ?></span>
                    </div>
                </div>

                <div class="card-body px-4 pb-4">
                    <!-- Informasi Layanan & Pelanggan -->
                    <div class="row g-3 mb-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small">Tipe Layanan <span class="text-pastel-rose">*</span></label>
                            <div class="btn-group w-100" role="group">
                                <input type="radio" class="btn-check" name="tipe_pesanan" id="tipeDineIn" value="Dine-In" checked>
                                <label class="btn btn-outline-espresso fw-semibold" for="tipeDineIn">
                                    <i class="bi bi-shop me-1"></i> Dine-In
                                </label>

                                <input type="radio" class="btn-check" name="tipe_pesanan" id="tipeTakeaway" value="Takeaway">
                                <label class="btn btn-outline-espresso fw-semibold" for="tipeTakeaway">
                                    <i class="bi bi-bag-check me-1"></i> Takeaway
                                </label>
                            </div>
                        </div>

                        <div class="col-md-6" id="nomorMejaGroup">
                            <label for="nomor_meja" class="form-label fw-semibold small">Pilih Nomor Meja <span class="text-pastel-rose">*</span></label>
                            <select class="form-select" id="nomor_meja" name="nomor_meja" required>
                                <option value="">-- Pilih Meja Tersedia --</option>
                                <?php for ($m = 1; $m <= 15; $m++): ?>
                                    <?php $mejaLabel = 'Meja ' . str_pad((string)$m, 2, '0', STR_PAD_LEFT); ?>
                                    <option value="<?= e($mejaLabel) ?>"><?= e($mejaLabel) ?></option>
                                <?php endfor; ?>
                                <option value="VIP 1">VIP Room 1</option>
                                <option value="VIP 2">VIP Room 2</option>
                                <option value="Outdoor 01">Outdoor 01</option>
                                <option value="Outdoor 02">Outdoor 02</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="nama_pemesan" class="form-label fw-semibold small">Nama Pemesan <span class="text-pastel-rose">*</span></label>
                            <input type="text" class="form-control" id="nama_pemesan" name="nama_pemesan" value="Pelanggan Umum" required>
                        </div>

                        <div class="col-md-6">
                            <label for="catatan_pesanan" class="form-label fw-semibold small">Catatan Meja / Pesanan</label>
                            <input type="text" class="form-control" id="catatan_pesanan" name="catatan_pesanan" placeholder="Contoh: Antar bersamaan, meja dekat bar">
                        </div>
                    </div>

                    <!-- Keranjang Item Dinamis -->
                    <div class="d-flex justify-content-between align-items-center mb-2 mt-4">
                        <div class="d-flex align-items-center gap-2">
                            <span class="fw-bold small text-uppercase text-espresso">
                                <i class="bi bi-cart3 me-1 text-pastel-rose"></i> Keranjang Pesanan
                            </span>
                            <span class="badge badge-pastel-lavender rounded-pill" id="cartItemCountBadge">0 item</span>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-espresso fw-semibold rounded-pill px-3" id="addItemRowBtn">
                            <i class="bi bi-plus-lg me-1"></i> Baris Baru
                        </button>
                    </div>

                    <div class="table-responsive border rounded-4 mb-4">
                        <table class="table table-sm align-middle mb-0" id="orderItemsTable">
                            <thead class="table-light small">
                                <tr>
                                    <th class="ps-3" style="width: 36%;">Menu</th>
                                    <th style="width: 17%;" class="text-center">Qty</th>
                                    <th style="width: 25%;">Catatan Barista/Dapur</th>
                                    <th style="width: 16%;" class="text-end">Subtotal</th>
                                    <th style="width: 6%;" class="text-center pe-2">#</th>
                                </tr>
                            </thead>
                            <tbody id="orderItemsBody">
                               
                            </tbody>
                        </table>
                    </div>

                    <div class="row g-3 align-items-stretch">
                        <div class="col-md-6">
                            <div class="bg-cream-soft rounded-4 p-3 border h-100">
                                <div class="mb-3">
                                    <label for="metode_bayar" class="form-label fw-semibold small">Metode Pembayaran</label>
                                    <select class="form-select" id="metode_bayar" name="metode_bayar" required>
                                        <option value="Tunai">Tunai (Cash)</option>
                                        <option value="QRIS">QRIS</option>
                                        <option value="Transfer Bank">Transfer Bank</option>
                                        <option value="Kartu Debit">Kartu Debit</option>
                                    </select>
                                </div>

                                <div id="cashPaymentSection">
                                    <label for="uang_dibayar" class="form-label fw-semibold small">Nominal Uang Tunai</label>
                                    <div class="input-group mb-2">
                                        <span class="input-group-text bg-white fw-bold text-espresso">Rp</span>
                                        <input type="number" class="form-control fw-bold" id="uang_dibayar" name="uang_dibayar" min="0" step="500" value="0">
                                    </div>
                                    <div class="d-flex flex-wrap gap-1 mb-2">
                                        <button type="button" class="btn btn-xs btn-espresso small py-1 px-2 rounded-pill" id="btnUangPas">Uang Pas</button>
                                        <button type="button" class="btn btn-xs btn-outline-espresso small py-1 px-2 rounded-pill" onclick="setCashNominal(50000)">50rb</button>
                                        <button type="button" class="btn btn-xs btn-outline-espresso small py-1 px-2 rounded-pill" onclick="setCashNominal(100000)">100rb</button>
                                        <button type="button" class="btn btn-xs btn-outline-espresso small py-1 px-2 rounded-pill" onclick="setCashNominal(200000)">200rb</button>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center small fw-bold p-2 rounded-3 bg-white border">
                                        <span class="text-muted">Kembalian:</span>
                                        <span id="displayUangKembali" class="text-pastel-mint fs-6">Rp 0</span>
                                    </div>
                                    <div id="cashWarningText" class="text-pastel-rose small fw-semibold mt-1 d-none">
                                        <i class="bi bi-exclamation-circle-fill me-1"></i>Uang tunai kurang dari Grand Total!
                                    </div>
                                </div>

                                <div class="mt-3">
                                    <label for="status_pesanan" class="form-label fw-semibold small">Status Pesanan</label>
                                    <select class="form-select form-select-sm" id="status_pesanan" name="status">
                                        <option value="Selesai" selected>Selesai (Lunas &amp; Ditutup)</option>
                                        <option value="Diproses">Diproses (Antrean Bar/Dapur)</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="checkout-summary-box h-100 d-flex flex-column justify-content-between">
                                <div>
                                    <div class="small text-uppercase text-espresso fw-extrabold mb-3" style="letter-spacing: 0.06em;">
                                        <i class="bi bi-receipt me-1 text-pastel-rose"></i> Ringkasan Tagihan
                                    </div>

                                    <div class="d-flex justify-content-between small mb-2 text-muted">
                                        <span>Subtotal Item</span>
                                        <span class="fw-bold text-dark" id="displaySubtotal">Rp 0</span>
                                    </div>

                                    <div class="d-flex justify-content-between align-items-center small mb-2 text-muted">
                                        <label for="diskon_nominal" class="mb-0">Diskon (Rp)</label>
                                        <input type="number" class="form-control form-control-sm text-end bg-white" style="width: 120px;"
                                               id="diskon_nominal" name="diskon_nominal" min="0" step="500" value="0">
                                    </div>

                                    <div class="d-flex justify-content-between small mb-2 text-muted">
                                        <span>Pajak PB1 (10%)</span>
                                        <span class="fw-bold text-dark" id="displayPajak">Rp 0</span>
                                    </div>
                                </div>

                                <div class="border-top pt-3 mt-3" style="border-color: rgba(196, 181, 253, 0.5) !important;">
                                    <div class="small text-muted fw-semibold">GRAND TOTAL</div>
                                    <div class="fs-3 fw-extrabold text-espresso" id="displayGrandTotal">Rp 0</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mt-4 d-flex justify-content-between align-items-center gap-2">
                        <button type="reset" class="btn btn-outline-espresso px-3 rounded-pill" onclick="setTimeout(resetPosForm, 10)">
                            <i class="bi bi-arrow-counterclockwise me-1"></i> Reset Form
                        </button>
                        <button type="submit" class="btn btn-espresso px-4 py-2.5 fw-bold rounded-pill" id="submitOrderBtn">
                            <i class="bi bi-printer-fill me-1"></i> Simpan &amp; Cetak Struk
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<?php
$productsJson = json_encode($products, JSON_UNESCAPED_UNICODE);
$posScriptUrl = e(base_url('assets/js/pos.js'));
$extraScripts = <<<HTML
<script>
window.POS_PRODUCTS = {$productsJson};
</script>
<script src="{$posScriptUrl}"></script>
HTML;
require_once __DIR__ . '/../includes/footer.php';
?>
