<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth_guard.php';
$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . base_url('pos/index.php'));
    exit;
}

verify_csrf();

$tipePesanan    = (string)($_POST['tipe_pesanan'] ?? 'Dine-In');
$nomorMeja      = trim((string)($_POST['nomor_meja'] ?? ''));
$namaPemesan    = trim((string)($_POST['nama_pemesan'] ?? 'Pelanggan Umum'));
$catatanPesanan = trim((string)($_POST['catatan_pesanan'] ?? ''));
$metodeBayar    = (string)($_POST['metode_bayar'] ?? 'Tunai');
$statusPesanan  = (string)($_POST['status'] ?? 'Selesai');
$diskonInput    = max(0, (float)($_POST['diskon_nominal'] ?? 0));
$uangDibayarIn  = max(0, (float)($_POST['uang_dibayar'] ?? 0));

$productIds = $_POST['product_id'] ?? [];
$quantities = $_POST['kuantiti'] ?? [];
$notes      = $_POST['catatan_khusus'] ?? [];

// Validasi dasar
if (!in_array($tipePesanan, ['Dine-In', 'Takeaway'], true)) {
    set_flash('danger', 'Tipe pesanan tidak valid.');
    header('Location: ' . base_url('pos/index.php'));
    exit;
}

if ($tipePesanan === 'Dine-In' && $nomorMeja === '') {
    set_flash('danger', 'Nomor Meja wajib dipilih untuk pesanan Dine-In.');
    header('Location: ' . base_url('pos/index.php'));
    exit;
}

if ($tipePesanan === 'Takeaway') {
    $nomorMeja = null;
}

if ($namaPemesan === '') {
    $namaPemesan = 'Pelanggan Umum';
}

if (!in_array($metodeBayar, ['Tunai', 'QRIS', 'Transfer Bank', 'Kartu Debit'], true)) {
    set_flash('danger', 'Metode pembayaran tidak valid.');
    header('Location: ' . base_url('pos/index.php'));
    exit;
}

if (!in_array($statusPesanan, ['Diproses', 'Selesai'], true)) {
    $statusPesanan = 'Selesai';
}

if (!is_array($productIds) || count($productIds) === 0) {
    set_flash('danger', 'Pilih minimal 1 item menu sebelum menyimpan transaksi.');
    header('Location: ' . base_url('pos/index.php'));
    exit;
}

// Susun baris item & agregasi kuantiti per product_id untuk pengecekan stok akurat
$rawItems = [];
$requestedQtyByProduct = [];

foreach ($productIds as $idx => $pidRaw) {
    $pid = (int)$pidRaw;
    $qty = (int)($quantities[$idx] ?? 0);
    $cat = trim((string)($notes[$idx] ?? ''));

    if ($pid <= 0 || $qty <= 0) {
        continue;
    }

    $rawItems[] = [
        'product_id'     => $pid,
        'kuantiti'       => $qty,
        'catatan_khusus' => $cat !== '' ? $cat : null,
    ];
    $requestedQtyByProduct[$pid] = ($requestedQtyByProduct[$pid] ?? 0) + $qty;
}

if (empty($rawItems)) {
    set_flash('danger', 'Tidak ada item pesanan valid dengan kuantiti minimal 1.');
    header('Location: ' . base_url('pos/index.php'));
    exit;
}

try {
    // Mulai Database Transaction (ACID)
    $pdo->beginTransaction();

    // Kunci baris produk (FOR UPDATE) & validasi ketersediaan stok
    $stmtLockProduct = $pdo->prepare("SELECT id, nama_produk, harga_jual, stok FROM products WHERE id = :id FOR UPDATE");
    $lockedProducts = [];

    foreach ($requestedQtyByProduct as $pid => $totalReqQty) {
        $stmtLockProduct->execute([':id' => $pid]);
        $prod = $stmtLockProduct->fetch();

        if (!$prod) {
            throw new RuntimeException('Salah satu menu yang dipilih tidak ditemukan di database.');
        }

        if ((int)$prod['stok'] < $totalReqQty) {
            throw new RuntimeException(sprintf(
                'Stok menu "%s" tidak mencukupi (diminta: %d, tersedia: %d).',
                $prod['nama_produk'],
                $totalReqQty,
                (int)$prod['stok']
            ));
        }

        $lockedProducts[$pid] = $prod;
    }

    // Hitung ulang nominal secara server-side agar anti-manipulasi
    $totalSubtotal = 0.0;
    $preparedDetails = [];

    foreach ($rawItems as $item) {
        $prod = $lockedProducts[$item['product_id']];
        $hargaSatuan = (float)$prod['harga_jual'];
        $subtotalBaris = $hargaSatuan * $item['kuantiti'];
        $totalSubtotal += $subtotalBaris;

        $preparedDetails[] = [
            'product_id'     => $item['product_id'],
            'harga_satuan'   => $hargaSatuan,
            'kuantiti'       => $item['kuantiti'],
            'subtotal_baris' => $subtotalBaris,
            'catatan_khusus' => $item['catatan_khusus'],
        ];
    }

    if ($diskonInput > $totalSubtotal) {
        throw new RuntimeException('Nominal diskon tidak boleh melebihi subtotal pesanan.');
    }

    $dpp = max(0.0, $totalSubtotal - $diskonInput);
    $pajakNominal = round($dpp * TAX_RATE);
    $grandTotal = $dpp + $pajakNominal;

    // Validasi pembayaran tunai >= grand_total
    if ($metodeBayar === 'Tunai') {
        if ($uangDibayarIn < $grandTotal) {
            throw new RuntimeException(sprintf(
                'Pembayaran tunai (%s) lebih kecil dari Grand Total (%s).',
                rupiah($uangDibayarIn),
                rupiah($grandTotal)
            ));
        }
        $uangDibayar = $uangDibayarIn;
        $uangKembali = $uangDibayar - $grandTotal;
    } else {
        $uangDibayar = $grandTotal;
        $uangKembali = 0.0;
    }

    // Generate nomor invoice unik atomik di dalam transaksi: INV-POS-YYYYMMDD-XXXX
    $todayPrefix = 'INV-POS-' . date('Ymd') . '-';
    $stmtSeq = $pdo->prepare("SELECT invoice_number FROM orders WHERE invoice_number LIKE :prefix ORDER BY id DESC LIMIT 1 FOR UPDATE");
    $stmtSeq->execute([':prefix' => $todayPrefix . '%']);
    $lastInv = $stmtSeq->fetchColumn();
    $seqNum = 1;
    if ($lastInv) {
        $parts = explode('-', $lastInv);
        $seqNum = ((int)end($parts)) + 1;
    }
    $invoiceNumber = $todayPrefix . str_pad((string)$seqNum, 4, '0', STR_PAD_LEFT);

    // Simpan header orders
    $stmtOrder = $pdo->prepare("
        INSERT INTO orders (
            invoice_number, user_id, nama_pemesan, tipe_pesanan, nomor_meja,
            catatan_pesanan, total_subtotal, pajak_nominal, diskon_nominal,
            grand_total, metode_bayar, uang_dibayar, uang_kembali, status
        ) VALUES (
            :invoice_number, :user_id, :nama_pemesan, :tipe_pesanan, :nomor_meja,
            :catatan_pesanan, :total_subtotal, :pajak_nominal, :diskon_nominal,
            :grand_total, :metode_bayar, :uang_dibayar, :uang_kembali, :status
        )
    ");
    $stmtOrder->execute([
        ':invoice_number'  => $invoiceNumber,
        ':user_id'         => (int)$user['id'],
        ':nama_pemesan'    => $namaPemesan,
        ':tipe_pesanan'    => $tipePesanan,
        ':nomor_meja'      => $nomorMeja,
        ':catatan_pesanan' => $catatanPesanan !== '' ? $catatanPesanan : null,
        ':total_subtotal'  => $totalSubtotal,
        ':pajak_nominal'   => $pajakNominal,
        ':diskon_nominal'  => $diskonInput,
        ':grand_total'     => $grandTotal,
        ':metode_bayar'    => $metodeBayar,
        ':uang_dibayar'    => $uangDibayar,
        ':uang_kembali'    => $uangKembali,
        ':status'          => $statusPesanan,
    ]);

    $orderId = (int)$pdo->lastInsertId();

    // Simpan order_details & kurangi stok produk
    $stmtDetail = $pdo->prepare("
        INSERT INTO order_details (order_id, product_id, harga_satuan, kuantiti, subtotal_baris, catatan_khusus)
        VALUES (:order_id, :product_id, :harga_satuan, :kuantiti, :subtotal_baris, :catatan_khusus)
    ");
    $stmtReduceStock = $pdo->prepare("UPDATE products SET stok = stok - :qty WHERE id = :id");

    foreach ($preparedDetails as $det) {
        $stmtDetail->execute([
            ':order_id'       => $orderId,
            ':product_id'     => $det['product_id'],
            ':harga_satuan'   => $det['harga_satuan'],
            ':kuantiti'       => $det['kuantiti'],
            ':subtotal_baris' => $det['subtotal_baris'],
            ':catatan_khusus' => $det['catatan_khusus'],
        ]);

        $stmtReduceStock->execute([
            ':qty' => $det['kuantiti'],
            ':id'  => $det['product_id'],
        ]);
    }

    // Commit semua perubahan secara bersamaan
    $pdo->commit();

    set_flash('success', 'Transaksi ' . $invoiceNumber . ' berhasil disimpan!');
    header('Location: ' . base_url('pos/receipt.php?id=' . $orderId));
    exit;
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    set_flash('danger', 'Transaksi dibatalkan (Rollback): ' . $e->getMessage());
    header('Location: ' . base_url('pos/index.php'));
    exit;
}
