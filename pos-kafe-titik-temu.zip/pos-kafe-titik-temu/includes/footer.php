</main>
        <footer class="app-footer text-center text-muted small py-3 border-top bg-white bg-opacity-75">
            &copy; <?= date('Y') ?> <strong class="text-espresso">Kafe Titik Temu Kopi</strong> 
        </footer>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Mobile Sidebar Toggle & Backdrop
const sidebarEl = document.getElementById('appSidebar');
const backdropEl = document.getElementById('sidebarBackdrop');
document.getElementById('sidebarToggle')?.addEventListener('click', () => {
    sidebarEl?.classList.toggle('show');
    backdropEl?.classList.toggle('show');
});
backdropEl?.addEventListener('click', () => {
    sidebarEl?.classList.remove('show');
    backdropEl?.classList.remove('show');
});

// Live Clock in Topbar
setInterval(() => {
    const clockEl = document.getElementById('liveClock');
    if (clockEl) {
        const now = new Date();
        clockEl.textContent = now.toLocaleTimeString('id-ID', { hour12: false }) + ' WIB';
    }
}, 1000);

// Auto-dismiss flash notification after 5 seconds
setTimeout(() => {
    const alertEl = document.getElementById('autoDismissAlert');
    if (alertEl && window.bootstrap) {
        bootstrap.Alert.getOrCreateInstance(alertEl).close();
    }
}, 5000);
</script>
<?php if (!empty($extraScripts)) echo $extraScripts; ?>
</body>
</html>
