<?php
$currentUser = $_SESSION['user'] ?? null;
$isAdmin = ($currentUser['role'] ?? '') === 'admin';
$currentUri = $_SERVER['REQUEST_URI'] ?? '';
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? APP_NAME) ?> — <?= e(APP_NAME) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= e(base_url('assets/css/style.css')) ?>" rel="stylesheet">
</head>
<body>
<div class="sidebar-backdrop" id="sidebarBackdrop"></div>

<div class="app-wrapper">
    <!-- Soft Pastel Sidebar -->
    <aside class="app-sidebar" id="appSidebar">
        <div class="sidebar-brand">
            <div class="brand-icon">
                <i class="bi bi-cup-hot-fill"></i>
            </div>
            <div>
                <div class="brand-title">Titik Temu Kopi</div>
                <div class="brand-sub">Melayani Sepenuh Hati</div>
            </div>
        </div>

        <div class="sidebar-menu">
            <div class="menu-label">OPERASIONAL KAFE</div>
            <a href="<?= e(base_url('dashboard/index.php')) ?>" class="nav-link-item <?= str_contains($currentUri, '/dashboard/') ? 'active' : '' ?>">
                <i class="bi bi-grid-1x2-fill"></i>
                <span>Dashboard Eksekutif</span>
            </a>
            <a href="<?= e(base_url('pos/index.php')) ?>" class="nav-link-item <?= str_contains($currentUri, '/pos/index.php') ? 'active' : '' ?>">
                <i class="bi bi-calculator-fill"></i>
                <span>Kasir &amp; Pemesanan</span>
            </a>
            <a href="<?= e(base_url('pos/history.php')) ?>" class="nav-link-item <?= str_contains($currentUri, '/pos/history.php') ? 'active' : '' ?>">
                <i class="bi bi-receipt-cutoff"></i>
                <span>Riwayat Transaksi</span>
            </a>

            <?php if ($isAdmin): ?>
                <div class="menu-label mt-3">MANAJEMEN &amp; ANALITIK</div>
                <a href="<?= e(base_url('products/index.php')) ?>" class="nav-link-item <?= str_contains($currentUri, '/products/') ? 'active' : '' ?>">
                    <i class="bi bi-box-seam-fill"></i>
                    <span>Menu &amp; Stok Produk</span>
                </a>
                <a href="<?= e(base_url('categories/index.php')) ?>" class="nav-link-item <?= str_contains($currentUri, '/categories/') ? 'active' : '' ?>">
                    <i class="bi bi-tags-fill"></i>
                    <span>Kategori Menu</span>
                </a>
                <a href="<?= e(base_url('reports/index.php')) ?>" class="nav-link-item <?= str_contains($currentUri, '/reports/') ? 'active' : '' ?>">
                    <i class="bi bi-bar-chart-line-fill"></i>
                    <span>Laporan &amp; Ekspor</span>
                </a>
                <a href="<?= e(base_url('users/index.php')) ?>" class="nav-link-item <?= str_contains($currentUri, '/users/') ? 'active' : '' ?>">
                    <i class="bi bi-people-fill"></i>
                    <span>Kelola Pengguna</span>
                </a>
            <?php endif; ?>
        </div>

        <div class="sidebar-footer">
            <div class="user-card">
                <div class="user-avatar">
                    <?= strtoupper(substr($currentUser['nama_lengkap'] ?? 'U', 0, 1)) ?>
                </div>
                <div class="user-info">
                    <div class="user-name text-truncate"><?= e($currentUser['nama_lengkap'] ?? '') ?></div>
                    <div class="user-role">
                        <span class="badge rounded-pill <?= $isAdmin ? 'badge-pastel-peach' : 'badge-pastel-sky' ?>" style="font-size: 0.68rem;">
                            <?= $isAdmin ? 'Administrator / Manager' : 'Kasir / Waiter' ?>
                        </span>
                    </div>
                </div>
            </div>
            <a href="<?= e(base_url('auth/logout.php')) ?>" class="btn btn-pastel-rose btn-sm w-100 mt-3 rounded-3" onclick="return confirm('Akhiri sesi kerja dan logout dari sistem ?');">
                <i class="bi bi-box-arrow-right me-1"></i> Keluar Sesi
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <div class="app-main">
        <header class="app-topbar">
            <div class="d-flex align-items-center gap-3">
                <button class="btn btn-light border d-lg-none rounded-3" type="button" id="sidebarToggle" aria-label="Toggle Menu">
                    <i class="bi bi-list fs-5 text-espresso"></i>
                </button>
                <div>
                    <h5 class="mb-0 fw-extrabold text-dark"><?= e($pageTitle ?? 'Dashboard') ?></h5>
                    <div class="d-flex align-items-center gap-2 text-muted small mt-0.5">
                        <span><i class="bi bi-calendar3 me-1 text-pastel-rose"></i><?= date('d M Y') ?></span>
                        <span>&bull;</span>
                        <span id="liveClock" class="badge badge-pastel-lavender rounded-pill fw-semibold"><?= date('H:i:s') ?> WIB</span>
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center gap-2">
                <?php if (!str_contains($currentUri, '/pos/index.php')): ?>
                    <a href="<?= e(base_url('pos/index.php')) ?>" class="btn btn-espresso btn-sm fw-bold px-3 py-2 rounded-pill">
                        <i class="bi bi-plus-circle-fill me-1"></i> Pesanan Baru
                    </a>
                <?php else: ?>
                    <span class="badge badge-pastel-mint px-3 py-2 rounded-pill fw-semibold">
                        <i class="bi bi-stars me-1"></i> Mode Kasir Aktif
                    </span>
                <?php endif; ?>
            </div>
        </header>

        <main class="app-content">
            <?php if ($flash): ?>
                <?php
                $flashIcon = match ($flash['type']) {
                    'success' => 'bi-check-circle-fill',
                    'danger'  => 'bi-exclamation-octagon-fill',
                    'warning' => 'bi-exclamation-triangle-fill',
                    default   => 'bi-info-circle-fill',
                };
                ?>
                <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show shadow-sm rounded-4 border-0 d-flex align-items-center" role="alert" id="autoDismissAlert">
                    <i class="bi <?= $flashIcon ?> fs-5 me-2"></i>
                    <div><?= e($flash['message']) ?></div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
