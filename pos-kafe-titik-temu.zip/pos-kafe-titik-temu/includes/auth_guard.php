<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

/**
 * Menghasilkan atau mengambil token CSRF sesi aktif.
 */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Memvalidasi token CSRF pada request POST.
 */
function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        set_flash('danger', 'Sesi formulir tidak valid (CSRF Token mismatch). Silakan coba lagi.');
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? base_url('dashboard/index.php')));
        exit;
    }
}

/**
 * Middleware wajib login: mengarahkan ke halaman login jika belum terautentikasi.
 */
function require_login(): array
{
    global $pdo;

    if (empty($_SESSION['user']['id'])) {
        set_flash('warning', 'Silakan login terlebih dahulu untuk mengakses sistem POS.');
        header('Location: ' . base_url('auth/login.php'));
        exit;
    }

    // Validasi status akun terbaru di database
    $stmt = $pdo->prepare("SELECT id, username, nama_lengkap, role, status FROM users WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => (int)$_SESSION['user']['id']]);
    $freshUser = $stmt->fetch();

    if (!$freshUser || $freshUser['status'] !== 'aktif') {
        $_SESSION = [];
        session_destroy();
        header('Location: ' . base_url('auth/login.php?err=inactive'));
        exit;
    }

    $_SESSION['user'] = $freshUser;
    return $freshUser;
}

/**
 * Middleware khusus Administrator / Manager.
 */
function require_admin(): array
{
    $user = require_login();
    if ($user['role'] !== 'admin') {
        set_flash('danger', 'Akses ditolak! Halaman tersebut hanya dapat diakses oleh Administrator / Manager.');
        header('Location: ' . base_url('dashboard/index.php'));
        exit;
    }
    return $user;
}
