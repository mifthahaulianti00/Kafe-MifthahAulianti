<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth_guard.php';

if (!empty($_SESSION['user']['id'])) {
    header('Location: ' . base_url('dashboard/index.php'));
    exit;
}

$error = '';
$info = '';
if (isset($_GET['msg']) && $_GET['msg'] === 'logout') {
    $info = 'Anda telah berhasil logout. Sesi pengguna telah dibersihkan.';
}
if (isset($_GET['err']) && $_GET['err'] === 'inactive') {
    $error = 'Akun Anda dinonaktifkan oleh Administrator.';
}
$flash = get_flash();
if ($flash) {
    if ($flash['type'] === 'danger') {
        $error = $flash['message'];
    } else {
        $info = $flash['message'];
    }
}

$usernameInput = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $usernameInput = trim((string)($_POST['username'] ?? ''));
    $passwordInput = (string)($_POST['password'] ?? '');

    if ($usernameInput === '' || $passwordInput === '') {
        $error = 'Username dan password wajib diisi.';
    } else {
        $stmt = $pdo->prepare("SELECT id, username, password_hash, nama_lengkap, role, status FROM users WHERE username = :username LIMIT 1");
        $stmt->execute([':username' => $usernameInput]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($passwordInput, $user['password_hash'])) {
            $error = 'Username tidak ditemukan atau password tidak cocok.';
        } elseif ($user['status'] !== 'aktif') {
            $error = 'Akun pengguna saat ini berstatus nonaktif. Hubungi Manager.';
        } else {
            session_regenerate_id(true);
            $_SESSION['user'] = [
                'id'           => (int)$user['id'],
                'username'     => $user['username'],
                'nama_lengkap' => $user['nama_lengkap'],
                'role'         => $user['role'],
                'status'       => $user['status'],
            ];
            set_flash('success', 'Selamat datang kembali, ' . $user['nama_lengkap'] . '!');
            header('Location: ' . base_url('dashboard/index.php'));
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — Kafe 'Titik Temu Kopi'</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= e(base_url('assets/css/style.css')) ?>" rel="stylesheet">
</head>
<body class="login-page">
<div class="container py-4">
    <div class="row justify-content-center align-items-center min-vh-100">
        <div class="col-lg-10 col-xl-9">
            <div class="card border-0 shadow-lg overflow-hidden rounded-4">
                <div class="row g-0">
                    
                    <div class="col-md-5 login-brand-panel p-4 p-lg-5 d-flex flex-column justify-content-between">
                        <div>
                            <div class="d-inline-flex align-items-center justify-content-center rounded-4 p-3 mb-4 shadow-sm"
                                 style="background: linear-gradient(135deg, #F9A8D4 0%, #C4B5FD 100%); border: 2px solid #FFFFFF;">
                                <i class="bi bi-cup-hot-fill fs-2 text-white"></i>
                            </div>
                            <h3 class="fw-extrabold mb-2 text-dark">Kafe Titik Temu Kopi</h3>
                            <p class="text-muted small mb-4 lh-base">
                               Mencatat pesanan Dine-In &amp; Takeaway dengan cepat dan akurat.
                            </p>
                        </div>
                    </div>

                    <!-- Right Login Form -->
                    <div class="col-md-7 p-4 p-lg-5 bg-white d-flex flex-column justify-content-center">
                        <div class="mb-4">
                            <span class="badge badge-pastel-lavender px-3 py-1 rounded-pill fw-semibold mb-2">
                                <i class="bi bi-shield-check me-1"></i> AUTENTIKASI SHIFT
                            </span>
                            <h3 class="fw-extrabold mb-1 text-dark">Selamat Datang Kembali</h3>
                            <p class="text-muted small mb-0">Masuk menggunakan akun kasir atau manager untuk memulai operasional.</p>
                        </div>

                        <?php if ($error !== ''): ?>
                            <div class="alert alert-danger py-2 px-3 rounded-3 small d-flex align-items-center border-0">
                                <i class="bi bi-exclamation-triangle-fill me-2 fs-6"></i>
                                <div><?= e($error) ?></div>
                            </div>
                        <?php endif; ?>

                        <?php if ($info !== ''): ?>
                            <div class="alert alert-success py-2 px-3 rounded-3 small d-flex align-items-center border-0">
                                <i class="bi bi-check-circle-fill me-2 fs-6"></i>
                                <div><?= e($info) ?></div>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="" novalidate>
                            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

                            <div class="mb-3">
                                <label for="username" class="form-label fw-semibold small text-dark">Username</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-cream-soft"><i class="bi bi-person text-pastel-rose"></i></span>
                                    <input type="text" class="form-control" id="username" name="username"
                                           value="<?= e($usernameInput) ?>" placeholder="Masukkan username Anda" required autofocus>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="password" class="form-label fw-semibold small text-dark">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-cream-soft"><i class="bi bi-lock text-espresso"></i></span>
                                    <input type="password" class="form-control" id="password" name="password"
                                           placeholder="Masukkan password Anda" required>
                                    <button class="btn btn-outline-espresso" type="button" id="togglePass" title="Tampilkan Password">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-espresso w-100 py-2.5 fw-bold rounded-pill">
                                <i class="bi bi-box-arrow-in-right me-1"></i> Masuk ke Dashboard
                            </button>
                        </form>

                        <div class="mt-4 pt-3 border-top d-flex justify-content-between align-items-center text-muted small">
                           
                            <span>&copy; <?= date('Y') ?> Titik Temu Kopi</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
function fillDemo(user, pass) {
    document.getElementById('username').value = user;
    document.getElementById('password').value = pass;
    const badge = document.getElementById('demoFilledBadge');
    if (badge) {
        badge.classList.remove('d-none');
        setTimeout(() => badge.classList.add('d-none'), 1800);
    }
}
document.getElementById('togglePass')?.addEventListener('click', function () {
    const input = document.getElementById('password');
    const icon = this.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'bi bi-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'bi bi-eye';
    }
});
</script>
</body>
</html>
