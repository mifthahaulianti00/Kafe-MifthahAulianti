<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth_guard.php';
$user = require_admin();
$pageTitle = 'Laporan Penjualan & Ekspor Data';

$startDate  = (string)($_GET['start_date'] ?? date('Y-m-01'));
$endDate    = (string)($_GET['end_date'] ?? date('Y-m-d'));
$categoryId = (int)($_GET['category_id'] ?? 0);
$metode     = (string)($_GET['metode_bayar'] ?? '');
$status     = (string)($_GET['status'] ?? 'Selesai');

$categories = $pdo->query("SELECT id, nama_kategori FROM categories ORDER BY id ASC")->fetchAll();

// Bangun query dinamis sesuai filter tanggal, kategori menu, metode bayar, dan status
$where = ["DATE(o.created_at) BETWEEN :start_date AND :end_date"];
$params = [
    ':start_date' => $startDate,
    ':end_date'   => $endDate,
];

if ($categoryId > 0) {
    $where[] = "p.category_id = :category_id";
    $params[':category_id'] = $categoryId;
}
if ($metode !== '') {
    $where[] = "o.metode_bayar = :metode";
    $params[':metode'] = $metode;
}
if ($status !== '') {
    $where[] = "o.status = :status";
    $params[':status'] = $status;
}

$whereSql = implode(' AND ', $where);

$sql = "
    SELECT o.id, o.invoice_number, o.created_at, o.tipe_pesanan, o.nomor_meja,
           o.total_subtotal, o.diskon_nominal, o.pajak_nominal, o.grand_total,
           o.metode_bayar, o.status, u.nama_lengkap AS kasir_nama,
           GROUP_CONCAT(CONCAT(p.nama_produk, ' (', od.kuantiti, ')') SEPARATOR ', ') AS item_terjual,
           SUM(od.subtotal_baris) AS filtered_item_subtotal
    FROM orders o
    INNER JOIN users u ON u.id = o.user_id
    INNER JOIN order_details od ON od.order_id = o.id
    INNER JOIN products p ON p.id = od.product_id
    WHERE {$whereSql}
    GROUP BY o.id
    ORDER BY o.created_at DESC, o.id DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

// Hitung Ringkasan Statistik (Summary Bar - 5 Metrik Wajib)
$totalOmsetBruto = 0.0;
$totalDiskon     = 0.0;
$totalPajak      = 0.0;
$totalGrand      = 0.0;

foreach ($rows as $r) {
    if ($categoryId > 0) {
        $bruto = (float)$r['filtered_item_subtotal'];
        $totalOmsetBruto += $bruto;
        $totalGrand += $bruto;
    } else {
        $totalOmsetBruto += (float)$r['total_subtotal'];
        $totalDiskon     += (float)$r['diskon_nominal'];
        $totalPajak      += (float)$r['pajak_nominal'];
        $totalGrand      += (float)$r['grand_total'];
    }
}

$omsetBersih = max(0.0, $totalOmsetBruto - $totalDiskon);
$jumlahTransaksi = count($rows);
$averageOrderValue = $jumlahTransaksi > 0 ? ($omsetBersih / $jumlahTransaksi) : 0.0;

$exportQueryString = http_build_query([
    'start_date'   => $startDate,
    'end_date'     => $endDate,
    'category_id'  => $categoryId,
    'metode_bayar' => $metode,
    'status'       => $status,
]);

require_once __DIR__ . '/../includes/header.php';
?>

<!-- Filter Dinamis Soft Pastel -->
<div class="card border-0 shadow-sm rounded-4 mb-4">
    <div class="card-header bg-white border-0 pt-4 px-4 pb-2 d-flex flex-wrap justify-content-between align-items-center gap-2">
        <div>
            <h6 class="fw-extrabold mb-0 text-dark"><i class="bi bi-funnel-fill me-1 text-pastel-rose"></i> Filter Laporan Penjualan</h6>
            <small class="text-muted">Saring data historis berdasarkan rentang tanggal, kategori menu, dan metode pembayaran</small>
        </div>
        <div class="d-flex flex-wrap gap-2">
            <a href="<?= e(base_url('reports/export_csv.php?' . $exportQueryString)) ?>" class="btn btn-pastel-mint btn-sm rounded-pill px-3">
                <i class="bi bi-file-earmark-spreadsheet-fill me-1"></i> Ekspor Excel / CSV
            </a>
            <a href="<?= e(base_url('reports/export_pdf.php?' . $exportQueryString)) ?>" target="_blank" class="btn btn-pastel-rose btn-sm rounded-pill px-3">
                <i class="bi bi-file-earmark-pdf-fill me-1"></i> Ekspor / Cetak PDF
            </a>
        </div>
    </div>

    <div class="card-body px-4 pb-4">
        <form method="GET" class="row g-3 align-items-end bg-cream-soft p-3 rounded-4 border">
            <div class="col-md-2">
                <label class="form-label small fw-semibold">Dari Tanggal</label>
                <input type="date" name="start_date" class="form-control form-control-sm" value="<?= e($startDate) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-semibold">Sampai Tanggal</label>
                <input type="date" name="end_date" class="form-control form-control-sm" value="<?= e($endDate) ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label small fw-semibold">Kategori Menu</label>
                <select name="category_id" class="form-select form-select-sm">
                    <option value="0">Semua Kategori</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= (int)$cat['id'] ?>" <?= $categoryId === (int)$cat['id'] ? 'selected' : '' ?>>
                            <?= e($cat['nama_kategori']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-semibold">Metode Pembayaran</label>
                <select name="metode_bayar" class="form-select form-select-sm">
                    <option value="">Semua Metode</option>
                    <?php foreach (['Tunai', 'QRIS', 'Transfer Bank', 'Kartu Debit'] as $m): ?>
                        <option value="<?= e($m) ?>" <?= $metode === $m ? 'selected' : '' ?>><?= e($m) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-semibold">Status Transaksi</label>
                <select name="status" class="form-select form-select-sm">
                    <option value="Selesai" <?= $status === 'Selesai' ? 'selected' : '' ?>>Selesai (Lunas)</option>
                    <option value="" <?= $status === '' ? 'selected' : '' ?>>Semua Status</option>
                    <option value="Diproses" <?= $status === 'Diproses' ? 'selected' : '' ?>>Diproses</option>
                    <option value="Dibatalkan" <?= $status === 'Dibatalkan' ? 'selected' : '' ?>>Dibatalkan</option>
                </select>
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-espresso btn-sm w-100 rounded-pill">Terapkan</button>
            </div>
        </form>
    </div>
</div>

<!-- Ringkasan Statistik (Summary Bar - 5 Indikator Wajib) -->
<div class="row g-3 mb-4">
    <div class="col-6 col-xl">
        <div class="card border-0 shadow-sm rounded-4 h-100 kpi-card">
            <div class="card-body p-3">
                <div class="text-muted small fw-bold">TOTAL OMSET BRUTO</div>
                <div class="fs-5 fw-extrabold text-dark mt-1"><?= e(rupiah($totalOmsetBruto)) ?></div>
                <small class="text-muted">Sebelum diskon &amp; pajak</small>
            </div>
        </div>
    </div>
    <div class="col-6 col-xl">
        <div class="card border-0 shadow-sm rounded-4 h-100 kpi-card">
            <div class="card-body p-3">
                <div class="text-muted small fw-bold">TOTAL DISKON</div>
                <div class="fs-5 fw-extrabold text-pastel-rose mt-1"><?= e(rupiah($totalDiskon)) ?></div>
                <small class="text-muted">Potongan voucher/promo</small>
            </div>
        </div>
    </div>
    <div class="col-6 col-xl">
        <div class="card border-0 shadow-sm rounded-4 h-100 kpi-card">
            <div class="card-body p-3">
                <div class="text-muted small fw-bold">PAJAK RESTORAN (PB1)</div>
                <div class="fs-5 fw-extrabold mt-1" style="color: #0284C7;"><?= e(rupiah($totalPajak)) ?></div>
                <small class="text-muted">Pajak PB1 10% terkumpul</small>
            </div>
        </div>
    </div>
    <div class="col-6 col-xl">
        <div class="card border-0 shadow-sm rounded-4 h-100 kpi-card border-start border-4" style="border-left-color: #6EE7B7 !important;">
            <div class="card-body p-3">
                <div class="text-muted small fw-bold">OMSET BERSIH (NET)</div>
                <div class="fs-5 fw-extrabold text-pastel-mint mt-1"><?= e(rupiah($omsetBersih)) ?></div>
                <small class="text-muted">Grand Total: <?= e(rupiah($totalGrand)) ?></small>
            </div>
        </div>
    </div>
    <div class="col-12 col-xl">
        <div class="card border-0 shadow-sm rounded-4 h-100 kpi-card">
            <div class="card-body p-3">
                <div class="text-muted small fw-bold">RATA-RATA TRANSAKSI (AOV)</div>
                <div class="fs-5 fw-extrabold text-espresso mt-1"><?= e(rupiah($averageOrderValue)) ?></div>
                <small class="text-muted">Dari <?= $jumlahTransaksi ?> transaksi</small>
            </div>
        </div>
    </div>
</div>

<!-- Tabel Laporan Penjualan -->
<div class="card border-0 shadow-sm rounded-4">
    <div class="card-header bg-white border-0 pt-4 px-4 pb-3">
        <h6 class="fw-extrabold mb-0 text-dark">Rincian Laporan Transaksi Penjualan</h6>
        <small class="text-muted">Periode <?= date('d M Y', strtotime($startDate)) ?> s/d <?= date('d M Y', strtotime($endDate)) ?></small>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light small text-uppercase">
                <tr>
                    <th class="ps-4">No. Faktur</th>
                    <th>Tanggal &amp; Jam</th>
                    <th>Kasir</th>
                    <th>Tipe Pesanan</th>
                    <th>Item Terjual</th>
                    <th class="text-end">Subtotal</th>
                    <th class="text-end">Pajak</th>
                    <th class="text-end">Grand Total</th>
                    <th class="text-center pe-4">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr>
                        <td colspan="9" class="text-center py-5 text-muted">Tidak ditemukan data transaksi pada periode dan filter yang dipilih.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td class="ps-4 fw-bold text-espresso"><?= e($r['invoice_number']) ?></td>
                            <td class="small text-muted"><?= date('d/m/Y H:i', strtotime($r['created_at'])) ?></td>
                            <td class="small"><?= e($r['kasir_nama']) ?></td>
                            <td class="small">
                                <?= e($r['tipe_pesanan']) ?>
                                <?= $r['nomor_meja'] ? ' (' . e($r['nomor_meja']) . ')' : '' ?>
                                <div class="text-muted" style="font-size: 0.72rem;"><?= e($r['metode_bayar']) ?></div>
                            </td>
                            <td class="small" style="max-width: 240px;"><?= e($r['item_terjual']) ?></td>
                            <td class="text-end"><?= e(rupiah($categoryId > 0 ? $r['filtered_item_subtotal'] : $r['total_subtotal'])) ?></td>
                            <td class="text-end text-muted"><?= e(rupiah($categoryId > 0 ? 0 : $r['pajak_nominal'])) ?></td>
                            <td class="text-end fw-bold text-dark"><?= e(rupiah($categoryId > 0 ? $r['filtered_item_subtotal'] : $r['grand_total'])) ?></td>
                            <td class="text-center pe-4">
                                <span class="badge <?= $r['status'] === 'Selesai' ? 'badge-pastel-mint' : ($r['status'] === 'Diproses' ? 'badge-pastel-peach' : 'badge-pastel-rose') ?> rounded-pill px-3">
                                    <?= e($r['status']) ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
