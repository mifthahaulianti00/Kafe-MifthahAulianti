<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth_guard.php';
$user = require_admin();

$startDate  = (string)($_GET['start_date'] ?? date('Y-m-01'));
$endDate    = (string)($_GET['end_date'] ?? date('Y-m-d'));
$categoryId = (int)($_GET['category_id'] ?? 0);
$metode     = (string)($_GET['metode_bayar'] ?? '');
$status     = (string)($_GET['status'] ?? 'Selesai');

$where = ["DATE(o.created_at) BETWEEN :start_date AND :end_date"];
$params = [
    ':start_date' => $startDate,
    ':end_date'   => $endDate,
];

if ($categoryId > 0) {
    $where[] = "p.category_id = :category_id";
    $params[':category_id'] = $categoryId;
}
if ($metode !== '') {
    $where[] = "o.metode_bayar = :metode";
    $params[':metode'] = $metode;
}
if ($status !== '') {
    $where[] = "o.status = :status";
    $params[':status'] = $status;
}

$sql = "
    SELECT o.invoice_number, o.created_at, u.nama_lengkap AS kasir_nama,
           o.tipe_pesanan, o.nomor_meja, o.metode_bayar,
           GROUP_CONCAT(CONCAT(p.nama_produk, ' (', od.kuantiti, ')') SEPARATOR ', ') AS item_terjual,
           o.total_subtotal, o.diskon_nominal, o.pajak_nominal, o.grand_total, o.status
    FROM orders o
    INNER JOIN users u ON u.id = o.user_id
    INNER JOIN order_details od ON od.order_id = o.id
    INNER JOIN products p ON p.id = od.product_id
    WHERE " . implode(' AND ', $where) . "
    GROUP BY o.id
    ORDER BY o.created_at DESC
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$totalBruto = array_sum(array_map(fn($r) => (float)$r['total_subtotal'], $rows));
$totalDiskon = array_sum(array_map(fn($r) => (float)$r['diskon_nominal'], $rows));
$totalPajak = array_sum(array_map(fn($r) => (float)$r['pajak_nominal'], $rows));
$totalGrand = array_sum(array_map(fn($r) => (float)$r['grand_total'], $rows));
$omsetBersih = max(0, $totalBruto - $totalDiskon);
$aov = count($rows) > 0 ? $omsetBersih / count($rows) : 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Penjualan PDF — Kafe Titik Temu Kopi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        @page { size: A4 landscape; margin: 14mm; }
        body { font-family: system-ui, -apple-system, sans-serif; color: #332C3E; font-size: 12px; }
        .kop-header { border-bottom: 3px solid #C4B5FD; padding-bottom: 12px; margin-bottom: 18px; }
        .thead-pastel th { background-color: #EDE9FE !important; color: #332C3E !important; }
        @media print {
            .no-print { display: none !important; }
        }
    </style>
</head>
<body class="p-4">

<div class="d-flex justify-content-between align-items-center mb-3 p-3 rounded-4 border no-print" style="background: linear-gradient(135deg, #FFF5F8 0%, #F7F5FF 100%);">
    <div>
        <strong>Pratinjau Dokumen Laporan PDF</strong>
        <span class="text-muted ms-2">Gunakan dialog cetak browser dan pilih "Save as PDF".</span>
    </div>
    <div class="d-flex gap-2">
        <button onclick="window.close()" class="btn btn-sm btn-outline-secondary rounded-pill px-3">Tutup</button>
        <button onclick="window.print()" class="btn btn-sm fw-bold text-white rounded-pill px-3" style="background: linear-gradient(135deg, #E57BA5 0%, #9A86E2 100%);">Cetak / Simpan PDF</button>
    </div>
</div>

<div class="kop-header d-flex justify-content-between align-items-end">
    <div>
        <h4 class="fw-bold mb-1" style="color: #6D5BBA;">KAFE TITIK TEMU KOPI</h4>
        <div class="text-muted"><?= e(CAFE_ADDRESS) ?> &bull; <?= e(CAFE_PHONE) ?></div>
    </div>
    <div class="text-end">
        <h5 class="fw-bold mb-1">LAPORAN PENJUALAN BERKALA</h5>
        <div>Periode: <strong><?= date('d/m/Y', strtotime($startDate)) ?></strong> s/d <strong><?= date('d/m/Y', strtotime($endDate)) ?></strong></div>
    </div>
</div>

<table class="table table-bordered table-sm mb-4 text-center">
    <thead class="thead-pastel">
        <tr>
            <th>Total Omset Bruto</th>
            <th>Total Diskon</th>
            <th>Total Pajak PB1 (10%)</th>
            <th>Omset Bersih (Net)</th>
            <th>Total Penerimaan (Grand Total)</th>
            <th>Rata-rata Transaksi (AOV)</th>
        </tr>
    </thead>
    <tbody>
        <tr class="fw-bold fs-6">
            <td><?= e(rupiah($totalBruto)) ?></td>
            <td style="color: #C84B7E;"><?= e(rupiah($totalDiskon)) ?></td>
            <td style="color: #0284C7;"><?= e(rupiah($totalPajak)) ?></td>
            <td style="color: #166534;"><?= e(rupiah($omsetBersih)) ?></td>
            <td><?= e(rupiah($totalGrand)) ?></td>
            <td style="color: #6D5BBA;"><?= e(rupiah($aov)) ?></td>
        </tr>
    </tbody>
</table>

<table class="table table-bordered table-striped table-sm align-middle">
    <thead class="thead-pastel">
        <tr>
            <th>No. Faktur</th>
            <th>Tanggal &amp; Jam</th>
            <th>Kasir</th>
            <th>Tipe</th>
            <th>Item Terjual</th>
            <th class="text-end">Subtotal</th>
            <th class="text-end">Pajak</th>
            <th class="text-end">Grand Total</th>
            <th class="text-center">Status</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($rows as $r): ?>
            <tr>
                <td class="fw-semibold"><?= e($r['invoice_number']) ?></td>
                <td><?= date('d/m/Y H:i', strtotime($r['created_at'])) ?></td>
                <td><?= e($r['kasir_nama']) ?></td>
                <td><?= e($r['tipe_pesanan']) ?><?= $r['nomor_meja'] ? ' (' . e($r['nomor_meja']) . ')' : '' ?></td>
                <td><?= e($r['item_terjual']) ?></td>
                <td class="text-end"><?= e(rupiah($r['total_subtotal'])) ?></td>
                <td class="text-end"><?= e(rupiah($r['pajak_nominal'])) ?></td>
                <td class="text-end fw-bold"><?= e(rupiah($r['grand_total'])) ?></td>
                <td class="text-center"><?= e($r['status']) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<div class="row mt-4 pt-3">
    <div class="col-8 small text-muted">
        Dicetak pada: <?= date('d F Y H:i:s') ?> WIB<br>
        Sistem Kasir &amp; Pemesanan — Kafe Titik Temu Kopi
    </div>
    <div class="col-4 text-center">
        <div>Mengetahui, Manager Operasional</div>
        <div style="height: 55px;"></div>
        <div class="fw-bold text-decoration-underline"><?= e($user['nama_lengkap']) ?></div>
    </div>
</div>

<script>
window.addEventListener('load', () => setTimeout(() => window.print(), 300));
</script>
</body>
</html>
