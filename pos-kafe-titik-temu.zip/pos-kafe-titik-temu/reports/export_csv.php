<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth_guard.php';
$user = require_admin();

$startDate  = (string)($_GET['start_date'] ?? date('Y-m-01'));
$endDate    = (string)($_GET['end_date'] ?? date('Y-m-d'));
$categoryId = (int)($_GET['category_id'] ?? 0);
$metode     = (string)($_GET['metode_bayar'] ?? '');
$status     = (string)($_GET['status'] ?? 'Selesai');

$where = ["DATE(o.created_at) BETWEEN :start_date AND :end_date"];
$params = [
    ':start_date' => $startDate,
    ':end_date'   => $endDate,
];

if ($categoryId > 0) {
    $where[] = "p.category_id = :category_id";
    $params[':category_id'] = $categoryId;
}
if ($metode !== '') {
    $where[] = "o.metode_bayar = :metode";
    $params[':metode'] = $metode;
}
if ($status !== '') {
    $where[] = "o.status = :status";
    $params[':status'] = $status;
}

$sql = "
    SELECT o.invoice_number, o.created_at, u.nama_lengkap AS kasir_nama,
           o.tipe_pesanan, o.nomor_meja, o.metode_bayar,
           GROUP_CONCAT(CONCAT(p.nama_produk, ' (', od.kuantiti, ')') SEPARATOR '; ') AS item_terjual,
           o.total_subtotal, o.diskon_nominal, o.pajak_nominal, o.grand_total, o.status
    FROM orders o
    INNER JOIN users u ON u.id = o.user_id
    INNER JOIN order_details od ON od.order_id = o.id
    INNER JOIN products p ON p.id = od.product_id
    WHERE " . implode(' AND ', $where) . "
    GROUP BY o.id
    ORDER BY o.created_at DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$filename = 'Laporan_Penjualan_TitikTemuKopi_' . $startDate . '_sd_' . $endDate . '.csv';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$output = fopen('php://output', 'w');
// UTF-8 BOM agar Microsoft Excel membaca karakter & format kolom secara otomatis dengan benar
fwrite($output, "\xEF\xBB\xBF");

fputcsv($output, ['LAPORAN PENJUALAN KAFE TITIK TEMU KOPI']);
fputcsv($output, ['Periode', $startDate . ' s/d ' . $endDate]);
fputcsv($output, ['Dicetak Oleh', $user['nama_lengkap'] . ' (' . date('d/m/Y H:i') . ')']);
fputcsv($output, []);

fputcsv($output, [
    'No. Faktur',
    'Tanggal & Jam',
    'Kasir',
    'Tipe Pesanan',
    'Nomor Meja',
    'Metode Pembayaran',
    'Item Terjual',
    'Subtotal (Rp)',
    'Diskon (Rp)',
    'Pajak PB1 (Rp)',
    'Grand Total (Rp)',
    'Status'
]);

$sumSub = 0;
$sumDis = 0;
$sumTax = 0;
$sumGrand = 0;

foreach ($rows as $r) {
    $sumSub += (float)$r['total_subtotal'];
    $sumDis += (float)$r['diskon_nominal'];
    $sumTax += (float)$r['pajak_nominal'];
    $sumGrand += (float)$r['grand_total'];

    fputcsv($output, [
        $r['invoice_number'],
        date('d/m/Y H:i', strtotime($r['created_at'])),
        $r['kasir_nama'],
        $r['tipe_pesanan'],
        $r['nomor_meja'] ?? '-',
        $r['metode_bayar'],
        $r['item_terjual'],
        (float)$r['total_subtotal'],
        (float)$r['diskon_nominal'],
        (float)$r['pajak_nominal'],
        (float)$r['grand_total'],
        $r['status']
    ]);
}

fputcsv($output, []);
fputcsv($output, ['TOTAL', '', '', '', '', '', '', $sumSub, $sumDis, $sumTax, $sumGrand, '']);

fclose($output);
exit;
