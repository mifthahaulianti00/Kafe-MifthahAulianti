/**
 * Modul Transaksi Inti (POS) - Kafe 'Titik Temu Kopi'
 * Dilengkapi stepper kuantiti (-/+), quick note chips, live item counter,
 * kalkulasi otomatis PB1 10%, diskon, kembalian, dan shortcut pencarian.
 */
const POS_PRODUCTS = window.POS_PRODUCTS || [];
const TAX_RATE = 0.10;

function formatRupiah(num) {
    return 'Rp ' + Math.round(num).toLocaleString('id-ID');
}

function buildProductOptions(selectedId = '') {
    let html = '<option value="">-- Pilih Menu --</option>';
    POS_PRODUCTS.forEach(p => {
        const disabled = Number(p.stok) <= 0 ? 'disabled' : '';
        const selected = String(p.id) === String(selectedId) ? 'selected' : '';
        const stockLabel = Number(p.stok) <= 0 ? 'HABIS' : `Stok: ${p.stok}`;
        html += `<option value="${p.id}" data-price="${p.harga_jual}" data-stock="${p.stok}" ${disabled} ${selected}>
            ${p.nama_produk} - Rp ${Number(p.harga_jual).toLocaleString('id-ID')} (${stockLabel})
        </option>`;
    });
    return html;
}

function appendQuickNote(btnEl, tagText) {
    const row = btnEl.closest('tr');
    const noteInput = row?.querySelector('.note-input');
    if (!noteInput) return;

    const current = noteInput.value.trim();
    if (current === '') {
        noteInput.value = tagText;
    } else if (!current.toLowerCase().includes(tagText.toLowerCase())) {
        noteInput.value = current + ', ' + tagText;
    }
}

function addOrderRow(productId = '', qty = 1, note = '') {
    const tbody = document.getElementById('orderItemsBody');
    if (!tbody) return;

    const tr = document.createElement('tr');
    tr.className = 'order-item-row';
    tr.innerHTML = `
        <td class="ps-3">
            <select name="product_id[]" class="form-select form-select-sm product-select" required>
                ${buildProductOptions(productId)}
            </select>
        </td>
        <td class="text-center">
            <div class="qty-stepper">
                <button type="button" class="qty-dec-btn" title="Kurangi">-</button>
                <input type="number" name="kuantiti[]" class="qty-input" min="1" value="${qty}" required>
                <button type="button" class="qty-inc-btn" title="Tambah">+</button>
            </div>
        </td>
        <td>
            <input type="text" name="catatan_khusus[]" class="form-control form-control-sm note-input mb-1"
                   value="${note}" placeholder="Catatan khusus...">
            <div class="d-flex flex-wrap gap-1">
                <span class="note-chip" onclick="appendQuickNote(this, 'Less Sugar')">Less Sugar</span>
                <span class="note-chip" onclick="appendQuickNote(this, 'Extra Ice')">Extra Ice</span>
                <span class="note-chip" onclick="appendQuickNote(this, 'Hot')">Hot</span>
            </div>
        </td>
        <td class="text-end fw-bold text-espresso row-subtotal">Rp 0</td>
        <td class="text-center pe-2">
            <button type="button" class="btn btn-sm btn-pastel-rose py-0 px-1.5 rounded-2 remove-row-btn" title="Hapus Item">
                <i class="bi bi-trash"></i>
            </button>
        </td>
    `;
    tbody.appendChild(tr);

    const selectEl = tr.querySelector('.product-select');
    const qtyEl = tr.querySelector('.qty-input');
    const decBtn = tr.querySelector('.qty-dec-btn');
    const incBtn = tr.querySelector('.qty-inc-btn');
    const removeBtn = tr.querySelector('.remove-row-btn');

    selectEl.addEventListener('change', () => {
        const opt = selectEl.selectedOptions[0];
        const maxStock = opt ? Number(opt.dataset.stock || 0) : 0;
        if (maxStock > 0) {
            qtyEl.max = maxStock;
            if (Number(qtyEl.value) > maxStock) qtyEl.value = maxStock;
        }
        recalculateTotals();
    });

    qtyEl.addEventListener('input', () => {
        const opt = selectEl.selectedOptions[0];
        const maxStock = opt ? Number(opt.dataset.stock || 0) : 0;
        if (Number(qtyEl.value) < 1) qtyEl.value = 1;
        if (maxStock > 0 && Number(qtyEl.value) > maxStock) {
            alert(`Stok tersedia untuk menu ini hanya ${maxStock}.`);
            qtyEl.value = maxStock;
        }
        recalculateTotals();
    });

    decBtn.addEventListener('click', () => {
        const cur = Number(qtyEl.value || 1);
        if (cur > 1) {
            qtyEl.value = cur - 1;
            recalculateTotals();
        }
    });

    incBtn.addEventListener('click', () => {
        const opt = selectEl.selectedOptions[0];
        const maxStock = opt ? Number(opt.dataset.stock || 0) : 0;
        const cur = Number(qtyEl.value || 1);
        if (maxStock > 0 && cur + 1 > maxStock) {
            alert(`Stok maksimal menu ini (${maxStock}) sudah tercapai.`);
            return;
        }
        qtyEl.value = cur + 1;
        recalculateTotals();
    });

    removeBtn.addEventListener('click', () => {
        tr.remove();
        if (document.querySelectorAll('.order-item-row').length === 0) {
            addOrderRow();
        }
        recalculateTotals();
    });

    if (productId) {
        selectEl.dispatchEvent(new Event('change'));
    } else {
        recalculateTotals();
    }
}

function quickAddProduct(productId) {
    const rows = Array.from(document.querySelectorAll('.order-item-row'));
    for (const row of rows) {
        const sel = row.querySelector('.product-select');
        const qtyInput = row.querySelector('.qty-input');
        if (String(sel.value) === String(productId)) {
            const maxStock = Number(sel.selectedOptions[0]?.dataset.stock || 0);
            const nextQty = Number(qtyInput.value) + 1;
            if (nextQty > maxStock) {
                alert(`Stok maksimal menu ini (${maxStock}) sudah tercapai.`);
                return;
            }
            qtyInput.value = nextQty;
            recalculateTotals();
            return;
        }
    }

    for (const row of rows) {
        const sel = row.querySelector('.product-select');
        if (!sel.value) {
            sel.value = String(productId);
            sel.dispatchEvent(new Event('change'));
            return;
        }
    }

    addOrderRow(productId, 1, '');
}

function recalculateTotals() {
    let subtotal = 0;
    let totalQty = 0;

    document.querySelectorAll('.order-item-row').forEach(row => {
        const sel = row.querySelector('.product-select');
        const qty = Number(row.querySelector('.qty-input')?.value || 0);
        const price = Number(sel?.selectedOptions[0]?.dataset.price || 0);
        const rowTotal = price * qty;
        subtotal += rowTotal;
        if (sel?.value) {
            totalQty += qty;
        }
        row.querySelector('.row-subtotal').textContent = formatRupiah(rowTotal);
    });

    const countBadge = document.getElementById('cartItemCountBadge');
    if (countBadge) {
        countBadge.textContent = `${totalQty} item`;
    }

    const diskonInput = document.getElementById('diskon_nominal');
    let diskon = Math.max(0, Number(diskonInput?.value || 0));
    if (diskon > subtotal) {
        diskon = subtotal;
        if (diskonInput) diskonInput.value = diskon;
    }

    const dpp = Math.max(0, subtotal - diskon);
    const pajak = Math.round(dpp * TAX_RATE);
    const grandTotal = dpp + pajak;

    document.getElementById('displaySubtotal').textContent = formatRupiah(subtotal);
    document.getElementById('displayPajak').textContent = formatRupiah(pajak);
    document.getElementById('displayGrandTotal').textContent = formatRupiah(grandTotal);
    document.getElementById('displayGrandTotal').dataset.raw = grandTotal;

    updatePaymentState(grandTotal);
}

function updatePaymentState(grandTotal) {
    const metode = document.getElementById('metode_bayar')?.value || 'Tunai';
    const cashSection = document.getElementById('cashPaymentSection');
    const uangDibayarEl = document.getElementById('uang_dibayar');
    const kembaliEl = document.getElementById('displayUangKembali');
    const warningEl = document.getElementById('cashWarningText');
    const submitBtn = document.getElementById('submitOrderBtn');

    if (metode === 'Tunai') {
        cashSection?.classList.remove('d-none');
        const dibayar = Number(uangDibayarEl?.value || 0);
        const kembali = dibayar - grandTotal;

        if (grandTotal > 0 && dibayar < grandTotal) {
            kembaliEl.textContent = formatRupiah(0);
            kembaliEl.className = 'text-danger fs-6';
            warningEl?.classList.remove('d-none');
            if (submitBtn) submitBtn.disabled = true;
        } else {
            kembaliEl.textContent = formatRupiah(Math.max(0, kembali));
            kembaliEl.className = 'text-success fs-6';
            warningEl?.classList.add('d-none');
            if (submitBtn) submitBtn.disabled = false;
        }
    } else {
        cashSection?.classList.add('d-none');
        if (uangDibayarEl) uangDibayarEl.value = grandTotal;
        warningEl?.classList.add('d-none');
        if (submitBtn) submitBtn.disabled = false;
    }
}

function setCashNominal(nominal) {
    const el = document.getElementById('uang_dibayar');
    if (el) {
        el.value = nominal;
        recalculateTotals();
    }
}

function resetPosForm() {
    const tbody = document.getElementById('orderItemsBody');
    if (tbody) {
        tbody.innerHTML = '';
        addOrderRow();
    }
    toggleTableField();
    recalculateTotals();
}

function toggleTableField() {
    const isDineIn = document.getElementById('tipeDineIn')?.checked;
    const mejaGroup = document.getElementById('nomorMejaGroup');
    const mejaSelect = document.getElementById('nomor_meja');
    if (!mejaGroup || !mejaSelect) return;

    if (isDineIn) {
        mejaGroup.classList.remove('opacity-50');
        mejaSelect.disabled = false;
        mejaSelect.required = true;
    } else {
        mejaGroup.classList.add('opacity-50');
        mejaSelect.value = '';
        mejaSelect.disabled = true;
        mejaSelect.required = false;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    addOrderRow();

    document.getElementById('addItemRowBtn')?.addEventListener('click', () => addOrderRow());
    document.getElementById('diskon_nominal')?.addEventListener('input', recalculateTotals);
    document.getElementById('uang_dibayar')?.addEventListener('input', recalculateTotals);
    document.getElementById('metode_bayar')?.addEventListener('change', recalculateTotals);

    document.getElementById('btnUangPas')?.addEventListener('click', () => {
        const grand = Number(document.getElementById('displayGrandTotal')?.dataset.raw || 0);
        setCashNominal(grand);
    });

    document.getElementById('tipeDineIn')?.addEventListener('change', toggleTableField);
    document.getElementById('tipeTakeaway')?.addEventListener('change', toggleTableField);
    toggleTableField();

    let activeCat = 'all';
    const searchInput = document.getElementById('menuSearchInput');
    const clearSearchBtn = document.getElementById('clearSearchBtn');
    const pills = document.querySelectorAll('#categoryFilterPills button');

    function filterCatalog() {
        const q = (searchInput?.value || '').trim().toLowerCase();
        document.querySelectorAll('.menu-catalog-item').forEach(card => {
            const matchesCat = activeCat === 'all' || card.dataset.cat === activeCat;
            const matchesText = q === '' || card.dataset.search.includes(q);
            card.style.display = (matchesCat && matchesText) ? '' : 'none';
        });
    }

    searchInput?.addEventListener('input', filterCatalog);
    clearSearchBtn?.addEventListener('click', () => {
        if (searchInput) {
            searchInput.value = '';
            filterCatalog();
            searchInput.focus();
        }
    });

    // Keyboard shortcut '/' untuk fokus cepat ke pencarian menu
    document.addEventListener('keydown', (e) => {
        if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
            e.preventDefault();
            searchInput?.focus();
        }
    });

    pills.forEach(btn => {
        btn.addEventListener('click', () => {
            pills.forEach(b => {
                b.classList.remove('btn-espresso', 'active');
                b.classList.add('btn-outline-secondary');
            });
            btn.classList.remove('btn-outline-secondary');
            btn.classList.add('btn-espresso', 'active');
            activeCat = btn.dataset.cat;
            filterCatalog();
        });
    });

    document.getElementById('posOrderForm')?.addEventListener('submit', function (e) {
        const isDineIn = document.getElementById('tipeDineIn')?.checked;
        const meja = document.getElementById('nomor_meja')?.value;
        if (isDineIn && !meja) {
            e.preventDefault();
            alert('Silakan pilih Nomor Meja terlebih dahulu untuk pesanan Dine-In.');
            return;
        }

        let validItems = 0;
        document.querySelectorAll('.order-item-row').forEach(row => {
            const pid = row.querySelector('.product-select')?.value;
            const qty = Number(row.querySelector('.qty-input')?.value || 0);
            if (pid && qty > 0) validItems++;
        });

        if (validItems === 0) {
            e.preventDefault();
            alert('Pilih minimal 1 menu makanan/minuman sebelum menyimpan transaksi.');
            return;
        }
    });
});
