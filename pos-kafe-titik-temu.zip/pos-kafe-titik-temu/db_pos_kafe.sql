-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2026 at 02:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pos_kafe`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama_kategori` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `nama_kategori`, `slug`, `status`) VALUES
(1, 'Coffee', 'coffee', 'aktif'),
(2, 'Non-Coffee', 'non-coffee', 'aktif'),
(3, 'Food', 'food', 'aktif'),
(4, 'Pastry', 'pastry', 'aktif');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `invoice_number` varchar(40) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `nama_pemesan` varchar(100) NOT NULL DEFAULT 'Pelanggan Umum',
  `tipe_pesanan` enum('Dine-In','Takeaway') NOT NULL DEFAULT 'Dine-In',
  `nomor_meja` varchar(20) DEFAULT NULL,
  `catatan_pesanan` text DEFAULT NULL,
  `total_subtotal` decimal(12,2) NOT NULL DEFAULT 0.00,
  `pajak_nominal` decimal(12,2) NOT NULL DEFAULT 0.00,
  `diskon_nominal` decimal(12,2) NOT NULL DEFAULT 0.00,
  `grand_total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `metode_bayar` enum('Tunai','QRIS','Transfer Bank','Kartu Debit') NOT NULL DEFAULT 'Tunai',
  `uang_dibayar` decimal(12,2) NOT NULL DEFAULT 0.00,
  `uang_kembali` decimal(12,2) NOT NULL DEFAULT 0.00,
  `status` enum('Diproses','Selesai','Dibatalkan') NOT NULL DEFAULT 'Selesai',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `invoice_number`, `user_id`, `nama_pemesan`, `tipe_pesanan`, `nomor_meja`, `catatan_pesanan`, `total_subtotal`, `pajak_nominal`, `diskon_nominal`, `grand_total`, `metode_bayar`, `uang_dibayar`, `uang_kembali`, `status`, `created_at`) VALUES
(1, 'INV-POS-20261117-0001', 2, 'Andi ', 'Dine-In', 'Meja 03', 'Antar bersamaan', 79000.00, 7900.00, 0.00, 86900.00, 'QRIS', 86900.00, 0.00, 'Selesai', '2026-11-17 03:15:00'),
(2, 'INV-POS-20261118-0001', 2, 'Nadia ', 'Takeaway', NULL, NULL, 64000.00, 5900.00, 5000.00, 64900.00, 'Tunai', 70000.00, 5100.00, 'Selesai', '2026-11-18 07:20:00'),
(3, 'INV-POS-20261119-0001', 3, 'Budi ', 'Dine-In', 'Meja 07', 'Meja dekat jendela', 112000.00, 11200.00, 0.00, 123200.00, 'Kartu Debit', 123200.00, 0.00, 'Selesai', '2026-11-19 12:05:00'),
(4, 'INV-POS-20261120-0001', 2, 'Citra ', 'Dine-In', 'Meja 02', NULL, 82000.00, 8200.00, 0.00, 90200.00, 'QRIS', 90200.00, 0.00, 'Selesai', '2026-11-20 04:40:00'),
(5, 'INV-POS-20261121-0001', 3, 'Fajri', 'Takeaway', NULL, 'Kantong terpisah', 96000.00, 9100.00, 5000.00, 100100.00, 'Transfer Bank', 100100.00, 0.00, 'Selesai', '2026-11-21 09:12:00'),
(6, 'INV-POS-20261122-0001', 2, 'Rina ', 'Dine-In', 'VIP 1', 'Meeting klien', 148000.00, 13800.00, 10000.00, 151800.00, 'Kartu Debit', 151800.00, 0.00, 'Selesai', '2026-11-22 06:30:00'),
(7, 'INV-POS-20261123-0001', 2, 'Hendra ', 'Dine-In', 'Meja 01', NULL, 79000.00, 7900.00, 0.00, 86900.00, 'Tunai', 100000.00, 13100.00, 'Selesai', '2026-11-23 01:45:00'),
(8, 'INV-POS-20261123-0002', 2, 'Tari ', 'Takeaway', NULL, 'Sedotan kertas', 66000.00, 6100.00, 5000.00, 67100.00, 'QRIS', 67100.00, 0.00, 'Selesai', '2026-11-23 03:22:00'),
(9, 'INV-POS-20261123-0003', 3, 'Kevin', 'Dine-In', 'Meja 05', 'Sajikan hangat', 110000.00, 11000.00, 0.00, 121000.00, 'Kartu Debit', 121000.00, 0.00, 'Selesai', '2026-11-23 05:50:00'),
(10, 'INV-POS-20261123-0004', 2, 'Sari', 'Dine-In', 'Meja 04', 'Sedang disiapkan barista', 48000.00, 4800.00, 0.00, 52800.00, 'QRIS', 52800.00, 0.00, 'Selesai', '2026-11-23 09:40:00'),
(11, 'INV-POS-20261123-0005', 2, 'Mifthah', 'Dine-In', 'Meja 03', NULL, 18000.00, 1800.00, 0.00, 19800.00, 'Tunai', 20000.00, 200.00, 'Selesai', '2026-11-23 11:15:59');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `harga_satuan` decimal(12,2) NOT NULL DEFAULT 0.00,
  `kuantiti` int(11) NOT NULL DEFAULT 1,
  `subtotal_baris` decimal(12,2) NOT NULL DEFAULT 0.00,
  `catatan_khusus` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `harga_satuan`, `kuantiti`, `subtotal_baris`, `catatan_khusus`) VALUES
(1, 1, 1, 22000.00, 2, 44000.00, 'Less Sugar, Extra Ice'),
(2, 1, 8, 35000.00, 1, 35000.00, 'Sedang pedas'),
(3, 2, 1, 22000.00, 2, 44000.00, 'Normal Ice'),
(4, 2, 11, 20000.00, 1, 20000.00, 'Hangatkan'),
(5, 3, 9, 38000.00, 2, 76000.00, 'No Onion'),
(6, 3, 2, 18000.00, 2, 36000.00, 'Hot'),
(7, 4, 5, 26000.00, 2, 52000.00, 'Less Sweet'),
(8, 4, 12, 30000.00, 1, 30000.00, NULL),
(9, 5, 4, 28000.00, 2, 56000.00, 'Extra Shot'),
(10, 5, 11, 20000.00, 2, 40000.00, NULL),
(11, 6, 1, 22000.00, 3, 66000.00, 'Less Sugar'),
(12, 6, 10, 32000.00, 1, 32000.00, NULL),
(13, 6, 3, 25000.00, 2, 50000.00, 'Hot Cappuccino'),
(14, 7, 1, 22000.00, 2, 44000.00, 'Less Sugar'),
(15, 7, 8, 35000.00, 1, 35000.00, NULL),
(16, 8, 1, 22000.00, 3, 66000.00, 'Extra Ice'),
(17, 9, 9, 38000.00, 2, 76000.00, NULL),
(18, 9, 7, 21000.00, 1, 21000.00, 'Less Ice'),
(19, 9, 11, 20000.00, 1, 13000.00, 'Promo bundling'),
(20, 10, 5, 26000.00, 1, 26000.00, 'Oat milk'),
(21, 10, 1, 22000.00, 1, 22000.00, 'Less Sugar'),
(22, 11, 2, 18000.00, 1, 18000.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `kode_produk` varchar(30) NOT NULL,
  `nama_produk` varchar(150) NOT NULL,
  `harga_jual` decimal(12,2) NOT NULL DEFAULT 0.00,
  `harga_pokok` decimal(12,2) NOT NULL DEFAULT 0.00,
  `stok` int(11) NOT NULL DEFAULT 0,
  `stok_minimum` int(11) NOT NULL DEFAULT 10,
  `unit` varchar(30) NOT NULL DEFAULT 'Cup',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `kode_produk`, `nama_produk`, `harga_jual`, `harga_pokok`, `stok`, `stok_minimum`, `unit`, `created_at`) VALUES
(1, 1, 'CF-001', 'Kopi Susu Titik Temu', 22000.00, 9500.00, 48, 10, 'Cup', '2026-11-23 11:57:11'),
(2, 1, 'CF-002', 'Americano Arabika', 18000.00, 7000.00, 39, 10, 'Cup', '2026-11-23 12:02:11'),
(3, 1, 'CF-003', 'Cappuccino Art Latte', 25000.00, 10500.00, 4, 10, 'Cup', '2026-11-23 12:06:24'),
(4, 1, 'CF-004', 'Caramel Macchiato Iced', 28000.00, 12000.00, 26, 10, 'Cup', '2026-11-23 12:08:14'),
(5, 2, 'NC-001', 'Matcha Ceremonial Latte', 26000.00, 11500.00, 32, 10, 'Cup', '2026-11-23 12:09:18'),
(6, 2, 'NC-002', 'Red Velvet Cream Cheese', 24000.00, 10000.00, 3, 8, 'Cup', '2026-11-23 12:12:01'),
(7, 2, 'NC-003', 'Lychee Yakult Breeze', 21000.00, 8000.00, 35, 10, 'Glass', '2026-11-23 12:14:25'),
(8, 3, 'FD-001', 'Nasi Goreng Spesial Titik Temu', 35000.00, 16000.00, 22, 5, 'Porsi', '2026-11-23 12:17:34'),
(9, 3, 'FD-002', 'Chicken Katsu Curry Rice', 38000.00, 18000.00, 19, 5, 'Porsi', '2026-11-23 12:18:46'),
(10, 3, 'FD-003', 'Spaghetti Aglio Olio Tuna', 32000.00, 14500.00, 16, 5, 'Porsi', '2026-11-23 12:19:22'),
(11, 4, 'PS-001', 'French Butter Croissant', 20000.00, 8500.00, 2, 8, 'Pcs', '2026-11-23 12:20:43'),
(12, 4, 'PS-002', 'Basque Burnt Cheesecake', 30000.00, 13500.00, 14, 5, 'Slice', '2026-11-23 12:21:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `role` enum('admin','kasir') NOT NULL DEFAULT 'kasir',
  `status` enum('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `nama_lengkap`, `role`, `status`, `created_at`) VALUES
(1, 'admin', '$2y$12$h8.SFZctXXBjOxjuTY5FuOxknB3s42DFMs1sKfV5Fh.5cU7GiuKj2', 'Mifthah Aulianti (Manager)', 'admin', 'aktif', '2026-11-23 11:42:11'),
(2, 'kasiraulia', '$2y$12$qa9UW2h94oSQcvU97KAaF.SOtVxUvZEMVwiP37V0Cujn5mNAU00XK', 'Aulia (Kasir)', 'kasir', 'aktif', '2026-11-23 11:46:25'),
(3, 'kasirmiftah', '$2y$12$qa9UW2h94oSQcvU97KAaF.SOtVxUvZEMVwiP37V0Cujn5mNAU00XK', 'Miftah (Waiter)', 'kasir', 'aktif', '2026-11-23 11:45:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_categories_slug` (`slug`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_orders_invoice` (`invoice_number`),
  ADD KEY `idx_orders_user` (`user_id`),
  ADD KEY `idx_orders_created_at` (`created_at`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_details_order` (`order_id`),
  ADD KEY `idx_details_product` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_products_kode` (`kode_produk`),
  ADD KEY `idx_products_category` (`category_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_users_username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `fk_details_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_details_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_products_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
