<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/auth_guard.php';

if (!empty($_SESSION['user']['id'])) {
    header('Location: ' . base_url('dashboard/index.php'));
} else {
    header('Location: ' . base_url('auth/login.php'));
}
exit;
